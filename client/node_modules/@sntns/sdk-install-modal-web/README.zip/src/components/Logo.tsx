import React from 'react';
const Logo = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 273 51">
<g id="Sentience logo">
<g id="Group">
<path id="Back" d="M27.2603 25.1153L26.2867 23.8742L27.0166 20.4061L25.7268 19.3355L25.7999 16.324L24.7473 15.6852L24.4734 12.6917L23.2079 11.949L22.8917 9.50325L21.918 8.9439L21.249 6.09606L19.9835 5.68234L19.3388 3.89403L18.5839 3.66251L17.5192 1.77033L16.3941 1.13148L15.1437 0L13.8932 1.13148L12.7676 1.74016L11.7214 3.67469L10.9305 3.88184L10.2731 5.68234L9.04412 6.06588L8.32636 8.96827L7.32834 9.52763L7.06142 11.9258L5.8197 12.6795L5.55163 15.673L4.46889 16.3542L4.57855 19.2868L3.28867 20.4182L4.00643 23.8498L3.06934 25.091L4.33485 27.7073L3.6049 29.3621L4.65166 30.2627L6.09938 31.4673L5.38161 32.5866L8.86773 34.2171L8.48418 34.8379L12.5122 36.0564L15.1437 36.9552L17.7751 36.0564L21.8693 34.8623L21.455 34.1938L24.9237 32.6109L24.1937 31.4731L25.6902 30.2261L26.7004 29.3134L25.9705 27.6707L27.2603 25.1153Z" fill="url(#paint0_linear_603_19788)"/>
<g id="Group_2" filter="url(#filter0_d_603_19788)">
<path id="Vector" d="M25.1035 18.7147L27.0868 20.4061L25.6751 22.6818L25.1035 18.7147Z" fill="url(#paint1_linear_603_19788)"/>
<path id="Vector_2" d="M25.6758 22.6818L26.1139 25.1763L27.0875 20.4061L25.6758 22.6818Z" fill="url(#paint2_linear_603_19788)"/>
<path id="Vector_3" d="M5.22644 18.7147L3.24316 20.4061L4.6549 22.6818L5.22644 18.7147Z" fill="url(#paint3_linear_603_19788)"/>
<path id="Vector_4" d="M4.6549 22.6818L4.21682 25.1763L3.24316 20.4061L4.6549 22.6818Z" fill="url(#paint4_linear_603_19788)"/>
<path id="Vector_5" d="M24.8057 29.8003L26.7947 29.3622L25.7457 30.2871L24.8057 29.8003Z" fill="url(#paint5_linear_603_19788)"/>
<path id="Vector_6" d="M26.7947 29.3622L25.7973 27.1718L24.8057 29.8003L26.7947 29.3622Z" fill="url(#paint6_linear_603_19788)"/>
<path id="Vector_7" d="M19.9082 34.9598L25.0312 32.6232L20.8267 34.0958L19.9082 34.9598Z" fill="#641C3B"/>
<path id="Vector_8" d="M24.2519 31.4308L25.0306 32.6232L20.8262 34.0958L24.2519 31.4308Z" fill="url(#paint7_linear_603_19788)"/>
<path id="Vector_9" d="M21.976 34.8989L17.7959 36.0565L18.8003 35.3857L21.976 34.8989Z" fill="#641C3B"/>
<path id="Vector_10" d="M21.9765 34.8989L21.1856 33.7912L18.8008 35.3857L21.9765 34.8989Z" fill="url(#paint8_linear_603_19788)"/>
<path id="Vector_11" d="M18.6767 3.69324L17.5771 1.71576L18.4168 3.60156L18.6767 3.69324Z" fill="url(#paint9_linear_603_19788)"/>
<path id="Vector_12" d="M22.4091 10.5634L21.3008 6.06595L21.0635 8.53025L22.4091 10.5634Z" fill="url(#paint10_linear_603_19788)"/>
<path id="Vector_13" d="M19.4103 3.8569L20.8081 7.70277L19.1104 5.26284L19.4103 3.8569Z" fill="url(#paint11_linear_603_19788)"/>
<path id="Vector_14" d="M19.4104 3.8569L18.417 3.60159L19.1104 5.26284L19.4104 3.8569Z" fill="url(#paint12_linear_603_19788)"/>
<path id="Vector_15" d="M19.9326 5.62781L21.3014 6.06589L21.0641 8.53019L19.9326 5.62781Z" fill="url(#paint13_linear_603_19788)"/>
<path id="Vector_16" d="M23.7656 14.8271L25.0793 18.4228L24.513 12.6366L23.7656 14.8271Z" fill="url(#paint14_linear_603_19788)"/>
<path id="Vector_17" d="M23.1807 11.8886L24.5129 12.6366L23.7656 14.827L23.1807 11.8886Z" fill="url(#paint15_linear_603_19788)"/>
<path id="Vector_18" d="M24.9824 27.6464L25.7315 22.9992L27.3307 25.091L24.9824 27.6464Z" fill="url(#paint16_linear_603_19788)"/>
<path id="Vector_19" d="M24.9818 27.6464L24.8965 30.0068L27.33 25.091L24.9818 27.6464Z" fill="url(#paint17_linear_603_19788)"/>
<path id="Vector_20" d="M16.415 1.1315L17.5773 1.71581L18.4169 3.6016L17.5047 2.05061L16.415 1.1315Z" fill="white"/>
<path id="Vector_21" d="M15.165 1.1315L15.8683 3.2552L15.165 1.77035V1.1315Z" fill="url(#paint18_linear_603_19788)"/>
<path id="Vector_22" d="M15.165 4.86712L15.8683 3.2552L15.165 1.77036V4.86712Z" fill="url(#paint19_linear_603_19788)"/>
<path id="Vector_23" d="M15.8008 1.1315L16.3909 1.71581L16.1234 3.2552L16.0503 2.03842L15.8008 1.1315Z" fill="url(#paint20_linear_603_19788)"/>
<path id="Vector_24" d="M17.3572 4.89086L16.3905 1.71576L16.123 3.25515L17.3572 4.89086Z" fill="white"/>
<path id="Vector_25" d="M16.3905 1.71576L16.123 3.25515L17.3572 4.89086L16.3905 1.71576Z" fill="url(#paint21_linear_603_19788)"/>
<path id="Vector_26" d="M17.3579 3.25515L17.3573 4.89086L16.3906 1.71576L17.3579 3.25515Z" fill="#9A2F5B"/>
<path id="Vector_27" d="M16.415 1.1315L17.3341 1.71581L17.5227 3.2552L17.0904 2.03842L16.415 1.1315Z" fill="url(#paint22_linear_603_19788)"/>
<path id="Vector_28" d="M18.3807 3.76577L17.334 1.71576L17.5226 3.25515L17.956 3.81219L18.3807 3.76577Z" fill="url(#paint23_linear_603_19788)"/>
<path id="Vector_29" d="M15.3135 5.11663L16.062 3.45596L16.3452 3.76581L15.3135 5.11663Z" fill="url(#paint24_linear_603_19788)"/>
<path id="Vector_30" d="M15.165 5.30865L16.6104 8.15592L15.165 5.93822V5.30865Z" fill="url(#paint25_linear_603_19788)"/>
<path id="Vector_31" d="M15.3135 5.11662L16.7554 7.89715L16.3452 3.76581L15.3135 5.11662Z" fill="url(#paint26_linear_603_19788)"/>
<path id="Vector_32" d="M15.165 11.1645L16.6104 8.15596L15.165 5.93826V11.1645Z" fill="url(#paint27_linear_603_19788)"/>
<path id="Vector_33" d="M15.165 12.8559V11.7424L17.3346 15.0823L15.165 12.8559Z" fill="url(#paint28_linear_603_19788)"/>
<path id="Vector_34" d="M15.165 12.8559V18.8609L17.3346 15.0823L15.165 12.8559Z" fill="url(#paint29_linear_603_19788)"/>
<path id="Vector_35" d="M15.165 19.5728V21.5439L17.9247 23.6154L15.165 19.5728Z" fill="url(#paint30_linear_603_19788)"/>
<path id="Vector_36" d="M15.165 21.5439L17.9247 23.6154L16.2501 25.6753L15.165 28.1698V21.5439Z" fill="url(#paint31_linear_603_19788)"/>
<path id="Vector_37" d="M15.4111 19.2259L18.2282 16.7436L17.6195 15.3684L15.4111 19.2259Z" fill="url(#paint32_linear_603_19788)"/>
<path id="Vector_38" d="M18.1673 23.2534L15.4111 19.2259L18.2282 16.7436L18.1673 23.2534Z" fill="url(#paint33_linear_603_19788)"/>
<path id="Vector_39" d="M18.168 23.2534L20.2975 19.1162L18.2289 16.7436L18.168 23.2534Z" fill="#9A2F5B"/>
<path id="Vector_40" d="M20.2974 19.1162L18.2288 16.7436L17.6201 15.3684L20.2974 19.1162Z" fill="url(#paint34_linear_603_19788)"/>
<path id="Vector_41" d="M17.3344 5.11662L16.7559 7.89715L16.3457 3.76581L17.3344 5.11662Z" fill="#9A2F5B"/>
<path id="Vector_42" d="M15.3809 11.4627L16.8199 8.41586L17.3763 9.50324L15.3809 11.4627Z" fill="url(#paint35_linear_603_19788)"/>
<path id="Vector_43" d="M17.3763 9.50327L15.3809 11.4628L17.5469 14.7481L17.3763 9.50327Z" fill="url(#paint36_linear_603_19788)"/>
<path id="Vector_44" d="M18.9587 11.4871L17.5475 14.7481L17.377 9.50327L18.9587 11.4871Z" fill="#9A2F5B"/>
<path id="Vector_45" d="M18.9585 11.4871L16.8203 8.41586L17.3768 9.50324L18.9585 11.4871Z" fill="url(#paint37_linear_603_19788)"/>
<path id="Vector_46" d="M15.165 31.3577V28.8266L17.5464 32.2245L15.165 31.3577Z" fill="url(#paint38_linear_603_19788)"/>
<path id="Vector_47" d="M15.165 34.4364L16.2727 33.0647L17.5464 32.2245L15.165 31.3576V34.4364Z" fill="url(#paint39_linear_603_19788)"/>
<path id="Vector_48" d="M15.165 34.6128V35.717L16.2362 35.6625L15.165 34.6128Z" fill="url(#paint40_linear_603_19788)"/>
<path id="Vector_49" d="M16.2362 35.6625L15.5788 35.9178L15.165 36.3466V35.717L16.2362 35.6625Z" fill="url(#paint41_linear_603_19788)"/>
<path id="Vector_50" d="M24.7996 28.0479L25.746 30.2871L22.293 31.7714L24.7996 28.0479Z" fill="url(#paint42_linear_603_19788)"/>
<path id="Vector_51" d="M21.6475 33.7001L25.7452 30.287L22.2921 31.7713L22.3896 32.3556L21.6475 33.7001Z" fill="url(#paint43_linear_603_19788)"/>
<path id="Vector_52" d="M25.8829 16.3241L25.6636 22.5663L24.2217 18.8243L25.8829 16.3241Z" fill="url(#paint44_linear_603_19788)"/>
<path id="Vector_53" d="M24.2216 18.8244L25.8828 16.3241L23.9111 15.1375L24.2216 18.8244Z" fill="url(#paint45_linear_603_19788)"/>
<path id="Vector_54" d="M23.0168 9.50327L23.3818 12.6917L22.2137 11.9612L21.9219 11.414L23.0168 9.50327Z" fill="#9A2F5B"/>
<path id="Vector_55" d="M21.9215 11.4141L23.0164 9.50331L21.2275 8.49368L21.9215 11.4141Z" fill="url(#paint46_linear_603_19788)"/>
<path id="Vector_56" d="M23.4727 23.2534L24.2212 19.2137L26.0646 20.8929L23.4727 23.2534Z" fill="url(#paint47_linear_603_19788)"/>
<path id="Vector_57" d="M23.4727 23.2534L24.3488 25.091L24.9209 27.4515L26.0646 20.8929L23.4727 23.2534Z" fill="url(#paint48_linear_603_19788)"/>
<path id="Vector_58" d="M22.0317 32.0197L19.0498 34.3998L22.609 33.4506L22.0317 32.0197Z" fill="url(#paint49_linear_603_19788)"/>
<path id="Vector_59" d="M19.0869 35.2099L19.3968 34.5699L19.0498 34.3998L22.609 33.4506L19.0869 35.2099Z" fill="url(#paint50_linear_603_19788)"/>
<path id="Vector_60" d="M17.9971 32.1973L21.4408 31.0171L18.9951 34.2293L18.7032 32.9945L17.9971 32.1973Z" fill="url(#paint51_linear_603_19788)"/>
<path id="Vector_61" d="M21.9642 31.7714L21.4409 31.0171L18.9951 34.2293L20.9662 32.5013L21.9642 31.7714Z" fill="#9A2F5B"/>
<path id="Vector_62" d="M17.9971 32.1972L21.4408 31.017L20.918 28.5713L17.9971 32.1972Z" fill="url(#paint52_linear_603_19788)"/>
<path id="Vector_63" d="M21.9642 31.7713L21.4408 31.017L20.918 28.5713L21.9642 31.7713Z" fill="url(#paint53_linear_603_19788)"/>
<path id="Vector_64" d="M17.541 5.06208L17.5474 3.45596L18.3812 3.76581L17.541 5.06208Z" fill="url(#paint54_linear_603_19788)"/>
<path id="Vector_65" d="M17.541 5.06208L19.4483 7.89715L18.3812 3.76581L17.541 5.06208Z" fill="url(#paint55_linear_603_19788)"/>
<path id="Vector_66" d="M19.0098 5.27212L19.4479 7.89715L18.3809 3.76581L19.0098 5.27212Z" fill="#9A2F5B"/>
<path id="Vector_67" d="M19.1533 5.36612L20.6161 5.9748L19.6703 8.15594L19.1533 5.36612Z" fill="url(#paint56_linear_603_19788)"/>
<path id="Vector_68" d="M21.7366 11.2573L20.6167 5.97479L19.6709 8.15593L21.7366 11.2573Z" fill="url(#paint57_linear_603_19788)"/>
<path id="Vector_69" d="M19.64 8.40195L19.293 11.414L21.1184 9.47888L19.64 8.40195Z" fill="url(#paint58_linear_603_19788)"/>
<path id="Vector_70" d="M21.5745 14.6448L19.293 11.414L21.1184 9.47891L21.5745 14.6448Z" fill="url(#paint59_linear_603_19788)"/>
<path id="Vector_71" d="M21.5752 14.6448L21.7365 11.2574L21.1191 9.47891L21.5752 14.6448Z" fill="#9A2F5B"/>
<path id="Vector_72" d="M21.891 11.7424L23.5946 12.7405L21.8057 14.979L21.891 11.7424Z" fill="url(#paint60_linear_603_19788)"/>
<path id="Vector_73" d="M24.0692 18.5325L23.5946 12.7405L21.8057 14.9791L24.0692 18.5325Z" fill="url(#paint61_linear_603_19788)"/>
<path id="Vector_74" d="M16.9688 8.15592L17.5229 5.30865L18.3811 5.88948L16.9688 8.15592Z" fill="url(#paint62_linear_603_19788)"/>
<path id="Vector_75" d="M18.3811 5.8895L16.9688 8.15593L19.0559 11.1645L18.3811 5.8895Z" fill="url(#paint63_linear_603_19788)"/>
<path id="Vector_76" d="M18.3809 5.8895L19.452 8.18263L19.0557 11.1645L18.3809 5.8895Z" fill="#9A2F5B"/>
<path id="Vector_77" d="M17.8242 15.0823L19.1971 11.7575L20.151 12.8008L17.8242 15.0823Z" fill="url(#paint64_linear_603_19788)"/>
<path id="Vector_78" d="M17.8242 15.0824L20.4521 18.7785L20.151 12.8008L17.8242 15.0824Z" fill="url(#paint65_linear_603_19788)"/>
<path id="Vector_79" d="M21.5012 14.9791L20.4515 18.7785L20.1504 12.8008L21.5012 14.9791Z" fill="#9A2F5B"/>
<path id="Vector_80" d="M20.708 19.1162L21.7362 15.3383L23.3452 16.5701L20.708 19.1162Z" fill="url(#paint66_linear_603_19788)"/>
<path id="Vector_81" d="M23.3452 16.5701L20.708 19.1162L23.2083 22.9586L23.3452 16.5701Z" fill="url(#paint67_linear_603_19788)"/>
<path id="Vector_82" d="M23.3449 16.5701L24.0569 18.8244L23.208 22.9586L23.3449 16.5701Z" fill="#9A2F5B"/>
<path id="Vector_83" d="M21.1426 28.2788L23.2634 23.6519L24.4772 25.8151L21.1426 28.2788Z" fill="url(#paint68_linear_603_19788)"/>
<path id="Vector_84" d="M21.1426 28.2788L22.0675 29.8304L22.2503 31.4731L24.4772 25.8151L21.1426 28.2788Z" fill="url(#paint69_linear_603_19788)"/>
<path id="Vector_85" d="M24.8054 27.6765L23.4244 29.4289L22.25 31.4731L24.477 25.8151L24.8054 27.6765Z" fill="#9A2F5B"/>
<path id="Vector_86" d="M15.3867 28.5162L18.1974 23.999L18.6721 26.2346L15.3867 28.5162Z" fill="url(#paint70_linear_603_19788)"/>
<path id="Vector_87" d="M20.76 28.3032L18.1982 23.999L18.6729 26.2346L20.76 28.3032Z" fill="url(#paint71_linear_603_19788)"/>
<path id="Vector_88" d="M20.7592 28.3032L18.9338 30.1043L17.7959 31.9477L18.6721 26.2346L20.7592 28.3032Z" fill="#9A2F5B"/>
<path id="Vector_89" d="M15.3867 28.5162L17.0294 30.171L17.7959 31.9477L18.6721 26.2346L15.3867 28.5162Z" fill="url(#paint72_linear_603_19788)"/>
<path id="Vector_90" d="M18.4355 23.5882L20.5407 19.4452L21.6849 21.3554L18.4355 23.5882Z" fill="url(#paint73_linear_603_19788)"/>
<path id="Vector_91" d="M18.4355 23.5882L20.0968 25.7327L20.9909 27.9777L21.6849 21.3554L18.4355 23.5882Z" fill="url(#paint74_linear_603_19788)"/>
<path id="Vector_92" d="M23.0257 23.3143L21.7556 25.449L20.9902 27.9777L21.6842 21.3554L23.0257 23.3143Z" fill="#9A2F5B"/>
<path id="Vector_93" d="M23.0258 23.3143L20.54 19.4452L21.6843 21.3554L23.0258 23.3143Z" fill="url(#paint75_linear_603_19788)"/>
<path id="Vector_94" d="M16.75 35.641L18.8134 34.542L19.2021 35.5192L16.75 35.641Z" fill="url(#paint76_linear_603_19788)"/>
<path id="Vector_95" d="M16.75 35.641L17.1335 35.7994L17.0169 36.2537L19.2021 35.5191L16.75 35.641Z" fill="url(#paint77_linear_603_19788)"/>
<path id="Vector_96" d="M15.333 34.5461L17.7056 32.4653L17.9493 33.9862L15.333 34.5461Z" fill="url(#paint78_linear_603_19788)"/>
<path id="Vector_97" d="M18.7518 34.3813L17.7051 32.4653L17.9488 33.9862L18.7518 34.3813Z" fill="url(#paint79_linear_603_19788)"/>
<path id="Vector_98" d="M18.752 34.3813L17.7175 34.759L16.5918 35.489L17.949 33.9861L18.752 34.3813Z" fill="#9A2F5B"/>
<path id="Vector_99" d="M15.333 34.5461L16.1604 34.8623L16.5921 35.489L17.9493 33.9861L15.333 34.5461Z" fill="url(#paint80_linear_603_19788)"/>
<path id="Vector_100" d="M15.6885 36.0565L16.4451 35.7907L16.665 36.2189L15.6885 36.0565Z" fill="url(#paint81_linear_603_19788)"/>
<path id="Vector_101" d="M16.665 36.219L15.6885 36.0565L15.9624 36.1969L15.9351 36.3379L16.665 36.219Z" fill="#641C3B"/>
<path id="Vector_102" d="M16.8933 36.0565L16.4453 35.7907L16.6652 36.2189L16.8933 36.0565Z" fill="url(#paint82_linear_603_19788)"/>
<path id="Vector_103" d="M5.52482 29.8003L3.53516 29.3622L4.58482 30.2871L5.52482 29.8003Z" fill="url(#paint83_linear_603_19788)"/>
<path id="Vector_104" d="M3.53516 29.3622L4.53318 27.1718L5.52482 29.8003L3.53516 29.3622Z" fill="url(#paint84_linear_603_19788)"/>
<path id="Vector_105" d="M10.4228 34.9598L5.2998 32.6232L9.50426 34.0958L10.4228 34.9598Z" fill="#641C3B"/>
<path id="Vector_106" d="M6.07849 31.4308L5.2998 32.6232L9.50426 34.0958L6.07849 31.4308Z" fill="url(#paint85_linear_603_19788)"/>
<path id="Vector_107" d="M8.35352 34.8989L12.5336 36.0565L11.5292 35.3857L8.35352 34.8989Z" fill="#641C3B"/>
<path id="Vector_108" d="M8.35352 34.8989L9.14439 33.7912L11.5292 35.3857L8.35352 34.8989Z" fill="url(#paint86_linear_603_19788)"/>
<path id="Vector_109" d="M11.6533 3.69324L12.7529 1.71576L11.9133 3.60156L11.6533 3.69324Z" fill="url(#paint87_linear_603_19788)"/>
<path id="Vector_110" d="M7.9209 10.5634L9.02917 6.06595L9.26649 8.53025L7.9209 10.5634Z" fill="url(#paint88_linear_603_19788)"/>
<path id="Vector_111" d="M10.9193 3.8569L9.52148 7.70277L11.2193 5.26284L10.9193 3.8569Z" fill="url(#paint89_linear_603_19788)"/>
<path id="Vector_112" d="M10.9199 3.8569L11.9133 3.60159L11.2199 5.26284L10.9199 3.8569Z" fill="url(#paint90_linear_603_19788)"/>
<path id="Vector_113" d="M10.3981 5.62781L9.0293 6.06589L9.26662 8.53019L10.3981 5.62781Z" fill="url(#paint91_linear_603_19788)"/>
<path id="Vector_114" d="M6.56465 14.8271L5.25098 18.4228L5.8173 12.6366L6.56465 14.8271Z" fill="url(#paint92_linear_603_19788)"/>
<path id="Vector_115" d="M7.14963 11.8886L5.81738 12.6366L6.56474 14.827L7.14963 11.8886Z" fill="url(#paint93_linear_603_19788)"/>
<path id="Vector_116" d="M5.34825 27.6464L4.59916 22.9992L3 25.091L5.34825 27.6464Z" fill="url(#paint94_linear_603_19788)"/>
<path id="Vector_117" d="M5.34825 27.6464L5.43355 30.0068L3 25.091L5.34825 27.6464Z" fill="url(#paint95_linear_603_19788)"/>
<path id="Vector_118" d="M13.9149 1.1315L12.7527 1.71581L11.9131 3.6016L12.8252 2.05061L13.9149 1.1315Z" fill="white"/>
<path id="Vector_119" d="M15.1646 1.1315L14.4619 3.2552L15.1646 1.77035V1.1315Z" fill="white"/>
<path id="Vector_120" d="M15.1646 4.86712L14.4619 3.2552L15.1646 1.77036V4.86712Z" fill="#9A2F5B"/>
<path id="Vector_121" d="M14.5296 1.1315L13.9395 1.71581L14.2069 3.2552L14.2801 2.03842L14.5296 1.1315Z" fill="url(#paint96_linear_603_19788)"/>
<path id="Vector_122" d="M12.9727 4.89086L13.9393 1.71576L14.2068 3.25515L12.9727 4.89086Z" fill="white"/>
<path id="Vector_123" d="M13.9393 1.71576L14.2068 3.25515L12.9727 4.89086L13.9393 1.71576Z" fill="url(#paint97_linear_603_19788)"/>
<path id="Vector_124" d="M12.9717 3.25515L12.9728 4.89086L13.9395 1.71576L12.9717 3.25515Z" fill="#9A2F5B"/>
<path id="Vector_125" d="M13.9153 1.1315L12.9962 1.71581L12.8076 3.2552L13.2399 2.03842L13.9153 1.1315Z" fill="url(#paint98_linear_603_19788)"/>
<path id="Vector_126" d="M11.9492 3.76577L12.996 1.71576L12.8074 3.25515L12.374 3.81219L11.9492 3.76577Z" fill="url(#paint99_linear_603_19788)"/>
<path id="Vector_127" d="M15.0161 5.11663L14.2675 3.45596L13.9844 3.76581L15.0161 5.11663Z" fill="white"/>
<path id="Vector_128" d="M15.1645 5.30865L13.7197 8.15592L15.1645 5.93822V5.30865Z" fill="white"/>
<path id="Vector_129" d="M15.0161 5.11662L13.5742 7.89715L13.9845 3.76581L15.0161 5.11662Z" fill="#9A2F5B"/>
<path id="Vector_130" d="M15.1645 11.1645L13.7197 8.15596L15.1645 5.93826V11.1645Z" fill="#9A2F5B"/>
<path id="Vector_131" d="M15.1651 12.8559V11.7424L12.9961 15.0823L15.1651 12.8559Z" fill="url(#paint100_linear_603_19788)"/>
<path id="Vector_132" d="M15.1651 12.8559V18.8609L12.9961 15.0823L15.1651 12.8559Z" fill="#9A2F5B"/>
<path id="Vector_133" d="M15.1653 19.5728V21.5439L12.4062 23.6154L15.1653 19.5728Z" fill="url(#paint101_linear_603_19788)"/>
<path id="Vector_134" d="M15.1653 21.5439L12.4062 23.6154L14.0808 25.6753L15.1653 28.1698V21.5439Z" fill="#9A2F5B"/>
<path id="Vector_135" d="M14.9187 19.2259L12.1016 16.7436L12.7102 15.3684L14.9187 19.2259Z" fill="url(#paint102_linear_603_19788)"/>
<path id="Vector_136" d="M12.1625 23.2534L14.9187 19.2259L12.1016 16.7436L12.1625 23.2534Z" fill="#9A2F5B"/>
<path id="Vector_137" d="M12.1627 23.2534L10.0332 19.1162L12.1018 16.7436L12.1627 23.2534Z" fill="url(#paint103_linear_603_19788)"/>
<path id="Vector_138" d="M10.0332 19.1162L12.1018 16.7436L12.7105 15.3684L10.0332 19.1162Z" fill="url(#paint104_linear_603_19788)"/>
<path id="Vector_139" d="M12.9961 5.11662L13.5746 7.89715L13.9848 3.76581L12.9961 5.11662Z" fill="url(#paint105_linear_603_19788)"/>
<path id="Vector_140" d="M14.9486 11.4627L13.5096 8.41586L12.9531 9.50324L14.9486 11.4627Z" fill="url(#paint106_linear_603_19788)"/>
<path id="Vector_141" d="M12.9538 9.50327L14.9493 11.4628L12.7832 14.7481L12.9538 9.50327Z" fill="#9A2F5B"/>
<path id="Vector_142" d="M11.3721 11.4871L12.7832 14.7481L12.9538 9.50327L11.3721 11.4871Z" fill="url(#paint107_linear_603_19788)"/>
<path id="Vector_143" d="M11.3721 11.4871L13.5103 8.41586L12.9538 9.50324L11.3721 11.4871Z" fill="url(#paint108_linear_603_19788)"/>
<path id="Vector_144" d="M15.1649 31.3577V28.8266L12.7842 32.2245L15.1649 31.3577Z" fill="url(#paint109_linear_603_19788)"/>
<path id="Vector_145" d="M15.1649 34.4364L14.0578 33.0647L12.7842 32.2245L15.1649 31.3576V34.4364Z" fill="#9A2F5B"/>
<path id="Vector_146" d="M15.1653 34.6128V35.717L14.0947 35.6625L15.1653 34.6128Z" fill="white"/>
<path id="Vector_147" d="M14.0947 35.6625L14.7516 35.9178L15.1653 36.3466V35.717L14.0947 35.6625Z" fill="#9A2F5B"/>
<path id="Vector_148" d="M5.53134 28.0479L4.58496 30.2871L8.038 31.7714L5.53134 28.0479Z" fill="url(#paint110_linear_603_19788)"/>
<path id="Vector_149" d="M8.68265 33.7001L4.58496 30.287L8.038 31.7713L7.94052 32.3556L8.68265 33.7001Z" fill="url(#paint111_linear_603_19788)"/>
<path id="Vector_150" d="M4.44727 16.3241L4.6666 22.5663L6.10851 18.8243L4.44727 16.3241Z" fill="url(#paint112_linear_603_19788)"/>
<path id="Vector_151" d="M6.10851 18.8244L4.44727 16.3241L6.41894 15.1375L6.10851 18.8244Z" fill="url(#paint113_linear_603_19788)"/>
<path id="Vector_152" d="M7.31322 9.50327L6.94824 12.6917L8.11628 11.9612L8.40814 11.414L7.31322 9.50327Z" fill="#9A2F5B"/>
<path id="Vector_153" d="M8.4084 11.4141L7.31348 9.50331L9.10237 8.49368L8.4084 11.4141Z" fill="url(#paint114_linear_603_19788)"/>
<path id="Vector_154" d="M6.85758 23.2534L6.10906 19.2137L4.26562 20.8929L6.85758 23.2534Z" fill="url(#paint115_linear_603_19788)"/>
<path id="Vector_155" d="M6.85758 23.2534L5.98141 25.091L5.40929 27.4515L4.26562 20.8929L6.85758 23.2534Z" fill="url(#paint116_linear_603_19788)"/>
<path id="Vector_156" d="M8.29902 32.0197L11.2809 34.3998L7.72168 33.4506L8.29902 32.0197Z" fill="url(#paint117_linear_603_19788)"/>
<path id="Vector_157" d="M11.2438 35.2099L10.9339 34.5699L11.2809 34.3998L7.72168 33.4506L11.2438 35.2099Z" fill="url(#paint118_linear_603_19788)"/>
<path id="Vector_158" d="M12.3328 32.1973L8.88965 31.0171L11.3354 34.2293L11.6272 32.9945L12.3328 32.1973Z" fill="url(#paint119_linear_603_19788)"/>
<path id="Vector_159" d="M8.36621 31.7714L8.88959 31.0171L11.3353 34.2293L9.36423 32.5013L8.36621 31.7714Z" fill="#9A2F5B"/>
<path id="Vector_160" d="M12.3328 32.1972L8.88965 31.017L9.41245 28.5713L12.3328 32.1972Z" fill="url(#paint120_linear_603_19788)"/>
<path id="Vector_161" d="M8.36621 31.7713L8.88959 31.017L9.41239 28.5713L8.36621 31.7713Z" fill="url(#paint121_linear_603_19788)"/>
<path id="Vector_162" d="M12.7894 5.06208L12.783 3.45596L11.9492 3.76581L12.7894 5.06208Z" fill="url(#paint122_linear_603_19788)"/>
<path id="Vector_163" d="M12.7891 5.06208L10.8818 7.89715L11.9489 3.76581L12.7891 5.06208Z" fill="url(#paint123_linear_603_19788)"/>
<path id="Vector_164" d="M11.3199 5.27212L10.8818 7.89715L11.9489 3.76581L11.3199 5.27212Z" fill="#9A2F5B"/>
<path id="Vector_165" d="M11.1772 5.36612L9.71387 5.9748L10.6602 8.15594L11.1772 5.36612Z" fill="url(#paint124_linear_603_19788)"/>
<path id="Vector_166" d="M8.59375 11.2573L9.71362 5.97479L10.66 8.15593L8.59375 11.2573Z" fill="url(#paint125_linear_603_19788)"/>
<path id="Vector_167" d="M10.6904 8.40195L11.0374 11.414L9.21191 9.47888L10.6904 8.40195Z" fill="url(#paint126_linear_603_19788)"/>
<path id="Vector_168" d="M8.75586 14.6448L11.0374 11.414L9.21193 9.47891L8.75586 14.6448Z" fill="#9A2F5B"/>
<path id="Vector_169" d="M8.75564 14.6448L8.59375 11.2574L9.21171 9.47891L8.75564 14.6448Z" fill="url(#paint127_linear_603_19788)"/>
<path id="Vector_170" d="M8.43895 11.7424L6.73535 12.7405L8.52425 14.979L8.43895 11.7424Z" fill="url(#paint128_linear_603_19788)"/>
<path id="Vector_171" d="M6.26074 18.5325L6.73538 12.7405L8.52428 14.9791L6.26074 18.5325Z" fill="url(#paint129_linear_603_19788)"/>
<path id="Vector_172" d="M13.3615 8.15592L12.8074 5.30865L11.9492 5.88948L13.3615 8.15592Z" fill="url(#paint130_linear_603_19788)"/>
<path id="Vector_173" d="M11.9492 5.8895L13.3616 8.15593L11.2744 11.1645L11.9492 5.8895Z" fill="url(#paint131_linear_603_19788)"/>
<path id="Vector_174" d="M11.9491 5.8895L10.8779 8.18263L11.2742 11.1645L11.9491 5.8895Z" fill="#9A2F5B"/>
<path id="Vector_175" d="M12.5065 15.0823L11.1336 11.7575L10.1797 12.8008L12.5065 15.0823Z" fill="url(#paint132_linear_603_19788)"/>
<path id="Vector_176" d="M12.5059 15.0824L9.87793 18.7785L10.1791 12.8008L12.5059 15.0824Z" fill="url(#paint133_linear_603_19788)"/>
<path id="Vector_177" d="M8.82812 14.9791L9.87779 18.7785L10.1789 12.8008L8.82812 14.9791Z" fill="#9A2F5B"/>
<path id="Vector_178" d="M9.62257 19.1162L8.59379 15.3383L6.98535 16.5701L9.62257 19.1162Z" fill="url(#paint134_linear_603_19788)"/>
<path id="Vector_179" d="M6.98535 16.5701L9.62257 19.1162L7.12229 22.9586L6.98535 16.5701Z" fill="url(#paint135_linear_603_19788)"/>
<path id="Vector_180" d="M6.9854 16.5701L6.27344 18.8244L7.12234 22.9586L6.9854 16.5701Z" fill="#9A2F5B"/>
<path id="Vector_181" d="M9.18818 28.2788L7.06739 23.6519L5.85352 25.8151L9.18818 28.2788Z" fill="url(#paint136_linear_603_19788)"/>
<path id="Vector_182" d="M9.18818 28.2788L8.26327 29.8304L8.0805 31.4731L5.85352 25.8151L9.18818 28.2788Z" fill="url(#paint137_linear_603_19788)"/>
<path id="Vector_183" d="M5.52441 27.6765L6.9054 29.4289L8.07981 31.4731L5.85283 25.8151L5.52441 27.6765Z" fill="#9A2F5B"/>
<path id="Vector_184" d="M14.9436 28.5162L12.1323 23.999L11.6582 26.2346L14.9436 28.5162Z" fill="url(#paint138_linear_603_19788)"/>
<path id="Vector_185" d="M9.57031 28.3032L12.1315 23.999L11.6575 26.2346L9.57031 28.3032Z" fill="url(#paint139_linear_603_19788)"/>
<path id="Vector_186" d="M9.57031 28.3032L11.3958 30.1043L12.5336 31.9477L11.6575 26.2346L9.57031 28.3032Z" fill="url(#paint140_linear_603_19788)"/>
<path id="Vector_187" d="M14.9436 28.5162L13.3009 30.171L12.5344 31.9477L11.6582 26.2346L14.9436 28.5162Z" fill="#9A2F5B"/>
<path id="Vector_188" d="M11.8949 23.5882L9.78975 19.4452L8.64551 21.3554L11.8949 23.5882Z" fill="url(#paint141_linear_603_19788)"/>
<path id="Vector_189" d="M11.8949 23.5882L10.2336 25.7327L9.33948 27.9777L8.64551 21.3554L11.8949 23.5882Z" fill="url(#paint142_linear_603_19788)"/>
<path id="Vector_190" d="M7.30469 23.3143L8.57484 25.449L9.34019 27.9777L8.64621 21.3554L7.30469 23.3143Z" fill="#9A2F5B"/>
<path id="Vector_191" d="M7.30469 23.3143L9.79046 19.4452L8.64621 21.3554L7.30469 23.3143Z" fill="url(#paint143_linear_603_19788)"/>
<path id="Vector_192" d="M13.58 35.641L11.5167 34.542L11.1279 35.5192L13.58 35.641Z" fill="url(#paint144_linear_603_19788)"/>
<path id="Vector_193" d="M13.58 35.641L13.1965 35.7994L13.3131 36.2537L11.1279 35.5191L13.58 35.641Z" fill="url(#paint145_linear_603_19788)"/>
<path id="Vector_194" d="M14.9982 34.5461L12.6255 32.4653L12.3818 33.9862L14.9982 34.5461Z" fill="url(#paint146_linear_603_19788)"/>
<path id="Vector_195" d="M11.5781 34.3813L12.6249 32.4653L12.3812 33.9862L11.5781 34.3813Z" fill="url(#paint147_linear_603_19788)"/>
<path id="Vector_196" d="M11.5781 34.3813L12.6127 34.759L13.7384 35.489L12.3812 33.9861L11.5781 34.3813Z" fill="url(#paint148_linear_603_19788)"/>
<path id="Vector_197" d="M14.9982 34.5461L14.1707 34.8623L13.739 35.489L12.3818 33.9861L14.9982 34.5461Z" fill="#9A2F5B"/>
<path id="Vector_198" d="M14.6416 36.0565L13.885 35.7907L13.665 36.2189L14.6416 36.0565Z" fill="url(#paint149_linear_603_19788)"/>
<path id="Vector_199" d="M13.665 36.219L14.6416 36.0565L14.3677 36.1969L14.395 36.3379L13.665 36.219Z" fill="#641C3B"/>
<path id="Vector_200" d="M13.4375 36.0565L13.8854 35.7907L13.6655 36.2189L13.4375 36.0565Z" fill="url(#paint150_linear_603_19788)"/>
</g>
</g>
<g id="Group_3">
<path id="Vector_201" d="M46.435 23.9921C45.8462 23.9921 45.2798 23.9312 44.7342 23.8107C44.1885 23.6903 43.7054 23.4956 43.2846 23.228C42.8639 22.9603 42.5338 22.6184 42.2915 22.2036C42.0491 21.7888 41.9287 21.2922 41.9287 20.7154C41.9287 20.6529 41.9317 20.592 41.9361 20.534C41.9406 20.476 41.9436 20.427 41.9436 20.3838H43.7083C43.7083 20.4151 43.7054 20.4626 43.7009 20.5251C43.6949 20.5875 43.6935 20.641 43.6935 20.6827C43.6935 21.0707 43.8094 21.4022 44.0399 21.6758C44.2703 21.9494 44.5944 22.1545 45.0092 22.2898C45.424 22.4266 45.8998 22.495 46.435 22.495C46.7294 22.495 47.0118 22.4772 47.2854 22.44C47.559 22.4028 47.8072 22.3448 48.0332 22.266C48.2592 22.1872 48.4555 22.0876 48.6235 21.9672C48.7915 21.8468 48.9223 21.7026 49.0174 21.5346C49.1126 21.3666 49.1587 21.1718 49.1587 20.9518C49.1587 20.6158 49.062 20.3377 48.8673 20.1162C48.6725 19.8962 48.4109 19.7118 48.0793 19.5646C47.7478 19.4175 47.3761 19.2866 46.9613 19.1707C46.5465 19.0547 46.1183 18.9402 45.6768 18.8243C45.2352 18.7083 44.807 18.5715 44.3922 18.4139C43.9774 18.2563 43.6043 18.0645 43.2742 17.8386C42.9441 17.6126 42.681 17.3286 42.4862 16.9881C42.2915 16.6477 42.1948 16.2299 42.1948 15.7363C42.1948 15.2427 42.2944 14.8443 42.4937 14.4756C42.6929 14.1083 42.9828 13.8006 43.3604 13.5538C43.7381 13.307 44.19 13.1212 44.7148 12.9948C45.2397 12.8684 45.8329 12.806 46.4945 12.806C47.0609 12.806 47.5976 12.8669 48.1016 12.9873C48.6056 13.1078 49.0472 13.2951 49.4248 13.5464C49.8024 13.7991 50.0998 14.1188 50.3154 14.5068C50.5309 14.8948 50.638 15.3572 50.638 15.8924V16.0812H48.8896V15.8761C48.8896 15.5401 48.79 15.2561 48.5908 15.0257C48.3915 14.7952 48.112 14.6168 47.7552 14.4904C47.3984 14.3641 46.9836 14.3016 46.5108 14.3016C45.9533 14.3016 45.4865 14.3566 45.1088 14.4666C44.7312 14.5767 44.4443 14.7298 44.251 14.9231C44.0562 15.1178 43.9596 15.3512 43.9596 15.6248C43.9596 15.9296 44.0592 16.1794 44.2584 16.3726C44.4576 16.5674 44.7238 16.7324 45.0538 16.8692C45.3854 17.006 45.757 17.1294 46.1718 17.2394C46.5866 17.3494 47.0118 17.4654 47.4475 17.5858C47.8831 17.7062 48.3083 17.846 48.7231 18.0036C49.1379 18.1612 49.511 18.3559 49.8411 18.5864C50.1726 18.8168 50.4373 19.1038 50.6365 19.4457C50.8357 19.7877 50.9353 20.2039 50.9353 20.6975C50.9353 21.4751 50.7406 22.107 50.3525 22.5961C49.9645 23.0837 49.4308 23.4391 48.7543 23.6591C48.0763 23.8791 47.3018 23.9906 46.4305 23.9906L46.435 23.9921Z" fill="url(#paint151_linear_603_19788)"/>
<path id="Vector_202" d="M52.9883 23.8033V12.9963H61.369V14.5083H54.753V17.5174H60.6762V19.0294H54.753V22.2898H61.4641V23.8018H52.9898L52.9883 23.8033Z" fill="url(#paint152_linear_603_19788)"/>
<path id="Vector_203" d="M63.4458 23.8033V12.9963H65.1466L70.0766 19.7698C70.1391 19.8323 70.2104 19.923 70.2892 20.0374C70.368 20.1534 70.4439 20.2679 70.5182 20.3838C70.5911 20.4998 70.6446 20.5935 70.6758 20.6678H70.7546V12.9963H72.4554V23.8033H70.817L65.8231 16.951C65.7384 16.8246 65.6343 16.6655 65.5079 16.4708C65.3815 16.276 65.2879 16.1273 65.224 16.0218H65.1452V23.8033H63.4443H63.4458Z" fill="url(#paint153_linear_603_19788)"/>
<path id="Vector_204" d="M78.016 23.8033V14.5097H74.4404V12.9977H83.3876V14.5097H79.7808V23.8033H78.016Z" fill="url(#paint154_linear_603_19788)"/>
<path id="Vector_205" d="M85.3711 23.8033V12.9963H87.1358V23.8033H85.3711Z" fill="url(#paint155_linear_603_19788)"/>
<path id="Vector_206" d="M89.1172 23.8033V12.9963H97.4979V14.5083H90.8819V17.5174H96.8051V19.0294H90.8819V22.2898H97.593V23.8018H89.1187L89.1172 23.8033Z" fill="url(#paint156_linear_603_19788)"/>
<path id="Vector_207" d="M99.5752 23.8033V12.9963H101.276L106.208 19.7698C106.27 19.8323 106.341 19.923 106.42 20.0374C106.499 20.1534 106.575 20.2679 106.649 20.3838C106.723 20.4998 106.775 20.5935 106.807 20.6678H106.885V12.9963H108.586V23.8033H106.948L101.954 16.951C101.869 16.8246 101.765 16.6655 101.639 16.4708C101.512 16.276 101.419 16.1273 101.355 16.0218H101.276V23.8033H99.5752Z" fill="url(#paint157_linear_603_19788)"/>
<path id="Vector_208" d="M115.767 23.9921C114.664 23.9921 113.727 23.7958 112.956 23.4018C112.184 23.0078 111.594 22.3968 111.183 21.5672C110.775 20.7376 110.569 19.682 110.569 18.4005C110.569 16.5108 111.029 15.1059 111.948 14.1871C112.866 13.2683 114.145 12.8089 115.783 12.8089C116.686 12.8089 117.498 12.9605 118.217 13.2653C118.937 13.5701 119.503 14.0235 119.918 14.6271C120.333 15.2308 120.541 16.0009 120.541 16.9345H118.745C118.745 16.3577 118.624 15.8745 118.382 15.485C118.14 15.0969 117.796 14.8026 117.35 14.6034C116.904 14.4041 116.387 14.3045 115.798 14.3045C115.062 14.3045 114.441 14.4487 113.931 14.7372C113.421 15.0256 113.039 15.4597 112.782 16.0366C112.524 16.6149 112.395 17.3494 112.395 18.2414V18.5878C112.395 19.4813 112.523 20.2158 112.782 20.7926C113.039 21.371 113.419 21.7991 113.923 22.0772C114.427 22.3552 115.052 22.4949 115.798 22.4949C116.408 22.4949 116.937 22.3983 117.389 22.2035C117.841 22.0088 118.19 21.7174 118.437 21.3293C118.684 20.9413 118.807 20.4581 118.807 19.8798H120.539C120.539 20.8149 120.331 21.5865 119.916 22.1961C119.502 22.8057 118.934 23.2561 118.216 23.5505C117.496 23.8449 116.68 23.9921 115.765 23.9921H115.767Z" fill="url(#paint158_linear_603_19788)"/>
<path id="Vector_209" d="M122.524 23.8033V12.9963H130.905V14.5083H124.289V17.5174H130.212V19.0294H124.289V22.2898H131V23.8018H122.526L122.524 23.8033Z" fill="url(#paint159_linear_603_19788)"/>
</g>
</g>
<defs>
<filter id="filter0_d_603_19788" x="0.58" y="1.1215" width="29.1711" height="40.0551" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="2.41"/>
<feGaussianBlur stdDeviation="1.21"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.392157 0 0 0 0 0.109804 0 0 0 0 0.231373 0 0 0 0.21 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_603_19788"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_603_19788" result="shape"/>
</filter>
<linearGradient id="paint0_linear_603_19788" x1="15.1645" y1="36.9552" x2="15.1645" y2="0" gradientUnits="userSpaceOnUse">
<stop stop-color="#B66285"/>
<stop offset="1" stop-color="#FFE3EF"/>
</linearGradient>
<linearGradient id="paint1_linear_603_19788" x1="26.0952" y1="18.7147" x2="26.0952" y2="22.6818" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint2_linear_603_19788" x1="26.3814" y1="20.4061" x2="26.3814" y2="25.1763" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint3_linear_603_19788" x1="4.2348" y1="18.7147" x2="4.2348" y2="22.6818" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint4_linear_603_19788" x1="3.94932" y1="20.4061" x2="3.94932" y2="25.1763" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint5_linear_603_19788" x1="25.8002" y1="29.3622" x2="25.8002" y2="30.2871" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint6_linear_603_19788" x1="25.8002" y1="27.1718" x2="25.8002" y2="29.8003" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint7_linear_603_19788" x1="22.9284" y1="31.4308" x2="22.9284" y2="34.0958" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint8_linear_603_19788" x1="20.3883" y1="35.3857" x2="20.3883" y2="33.7912" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint9_linear_603_19788" x1="17.5771" y1="2.7045" x2="18.6767" y2="2.7045" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint10_linear_603_19788" x1="21.736" y1="10.5634" x2="21.736" y2="6.06595" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint11_linear_603_19788" x1="19.9592" y1="3.8569" x2="19.9592" y2="7.70277" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint12_linear_603_19788" x1="18.9137" y1="3.60159" x2="18.9137" y2="5.26284" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint13_linear_603_19788" x1="20.6167" y1="5.62781" x2="20.6167" y2="8.53019" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint14_linear_603_19788" x1="24.4225" y1="12.6366" x2="24.4225" y2="18.4228" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint15_linear_603_19788" x1="23.8468" y1="11.8886" x2="23.8468" y2="14.827" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint16_linear_603_19788" x1="26.1563" y1="22.9992" x2="26.1563" y2="27.6464" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint17_linear_603_19788" x1="26.1133" y1="25.091" x2="26.1133" y2="30.0068" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint18_linear_603_19788" x1="15.5167" y1="3.2552" x2="15.5167" y2="1.1315" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint19_linear_603_19788" x1="15.5167" y1="1.77036" x2="15.5167" y2="4.86712" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint20_linear_603_19788" x1="16.0961" y1="1.1315" x2="16.0961" y2="3.2552" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint21_linear_603_19788" x1="16.7404" y1="1.71576" x2="16.7404" y2="4.89086" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint22_linear_603_19788" x1="16.9686" y1="1.1315" x2="16.9686" y2="3.2552" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint23_linear_603_19788" x1="17.8574" y1="1.71576" x2="17.8574" y2="3.81219" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint24_linear_603_19788" x1="15.8293" y1="3.45596" x2="15.8293" y2="5.11663" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint25_linear_603_19788" x1="15.888" y1="8.15592" x2="15.888" y2="5.30865" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint26_linear_603_19788" x1="16.0347" y1="3.76581" x2="16.0347" y2="7.89715" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint27_linear_603_19788" x1="15.888" y1="5.93826" x2="15.888" y2="11.1645" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint28_linear_603_19788" x1="16.2501" y1="15.0823" x2="16.2501" y2="11.7424" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint29_linear_603_19788" x1="16.2501" y1="12.8559" x2="16.2501" y2="18.8609" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint30_linear_603_19788" x1="16.5449" y1="23.6154" x2="16.5449" y2="19.5728" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint31_linear_603_19788" x1="16.5449" y1="21.5439" x2="16.5449" y2="28.1698" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint32_linear_603_19788" x1="16.82" y1="19.2259" x2="16.82" y2="15.3684" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint33_linear_603_19788" x1="16.82" y1="16.7436" x2="16.82" y2="23.2534" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#641C3B"/>
</linearGradient>
<linearGradient id="paint34_linear_603_19788" x1="18.9587" y1="15.3684" x2="18.9587" y2="19.1162" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint35_linear_603_19788" x1="16.3783" y1="11.4627" x2="16.3783" y2="8.41586" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint36_linear_603_19788" x1="16.4636" y1="9.50327" x2="16.4636" y2="14.7481" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint37_linear_603_19788" x1="17.8891" y1="8.41586" x2="17.8891" y2="11.4871" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#FFE3EF"/>
</linearGradient>
<linearGradient id="paint38_linear_603_19788" x1="16.3557" y1="32.2245" x2="16.3557" y2="28.8266" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint39_linear_603_19788" x1="16.3557" y1="31.3576" x2="16.3557" y2="34.4364" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint40_linear_603_19788" x1="15.7006" y1="35.717" x2="15.7006" y2="34.6128" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint41_linear_603_19788" x1="15.7006" y1="35.6625" x2="15.7006" y2="36.3466" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint42_linear_603_19788" x1="24.0192" y1="28.0479" x2="24.0192" y2="31.7714" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint43_linear_603_19788" x1="23.6963" y1="30.287" x2="23.6963" y2="33.7001" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint44_linear_603_19788" x1="25.052" y1="16.3241" x2="25.052" y2="22.5663" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint45_linear_603_19788" x1="24.897" y1="15.1375" x2="24.897" y2="18.8244" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint46_linear_603_19788" x1="22.1223" y1="8.49368" x2="22.1223" y2="11.4141" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint47_linear_603_19788" x1="24.7689" y1="19.2137" x2="24.7689" y2="23.2534" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint48_linear_603_19788" x1="24.7689" y1="20.8929" x2="24.7689" y2="27.4515" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint49_linear_603_19788" x1="20.8294" y1="32.0197" x2="20.8294" y2="34.3998" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint50_linear_603_19788" x1="20.8294" y1="33.4506" x2="20.8294" y2="35.2099" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint51_linear_603_19788" x1="19.7192" y1="31.0171" x2="19.7192" y2="34.2293" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint52_linear_603_19788" x1="19.7192" y1="32.1972" x2="19.7192" y2="28.5713" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint53_linear_603_19788" x1="21.4408" y1="28.5713" x2="21.4408" y2="31.7713" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint54_linear_603_19788" x1="17.9611" y1="3.45596" x2="17.9611" y2="5.06208" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint55_linear_603_19788" x1="18.4949" y1="3.76581" x2="18.4949" y2="7.89715" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint56_linear_603_19788" x1="19.885" y1="5.36612" x2="19.885" y2="8.15594" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint57_linear_603_19788" x1="20.7037" y1="5.97479" x2="20.7037" y2="11.2573" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint58_linear_603_19788" x1="20.2057" y1="8.40195" x2="20.2057" y2="11.414" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint59_linear_603_19788" x1="20.4337" y1="9.47891" x2="20.4337" y2="14.6448" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint60_linear_603_19788" x1="22.7004" y1="11.7424" x2="22.7004" y2="14.979" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint61_linear_603_19788" x1="22.9377" y1="12.7405" x2="22.9377" y2="18.5325" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint62_linear_603_19788" x1="17.6749" y1="5.30865" x2="17.6749" y2="8.15592" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint63_linear_603_19788" x1="18.0126" y1="5.8895" x2="18.0126" y2="11.1645" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint64_linear_603_19788" x1="18.9876" y1="11.7575" x2="18.9876" y2="15.0823" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint65_linear_603_19788" x1="19.1385" y1="12.8008" x2="19.1385" y2="18.7785" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint66_linear_603_19788" x1="22.0263" y1="15.3383" x2="22.0263" y2="19.1162" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint67_linear_603_19788" x1="22.0263" y1="16.5701" x2="22.0263" y2="22.9586" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint68_linear_603_19788" x1="22.8096" y1="23.6519" x2="22.8096" y2="28.2788" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint69_linear_603_19788" x1="22.8096" y1="25.8151" x2="22.8096" y2="31.4731" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint70_linear_603_19788" x1="17.0294" y1="28.5162" x2="17.0294" y2="23.999" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint71_linear_603_19788" x1="19.4794" y1="23.999" x2="19.4794" y2="28.3032" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint72_linear_603_19788" x1="17.0294" y1="26.2346" x2="17.0294" y2="31.9477" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint73_linear_603_19788" x1="20.0602" y1="19.4452" x2="20.0602" y2="23.5882" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint74_linear_603_19788" x1="20.0602" y1="21.3554" x2="20.0602" y2="27.9777" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint75_linear_603_19788" x1="21.7829" y1="19.4452" x2="21.7829" y2="23.3143" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint76_linear_603_19788" x1="17.9761" y1="35.641" x2="17.9761" y2="34.542" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint77_linear_603_19788" x1="17.9761" y1="35.5191" x2="17.9761" y2="36.2537" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint78_linear_603_19788" x1="16.6409" y1="34.5461" x2="16.6409" y2="32.4653" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint79_linear_603_19788" x1="18.2285" y1="32.4653" x2="18.2285" y2="34.3813" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint80_linear_603_19788" x1="16.6409" y1="33.9861" x2="16.6409" y2="35.489" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint81_linear_603_19788" x1="16.177" y1="36.2189" x2="16.177" y2="35.7907" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint82_linear_603_19788" x1="16.6693" y1="36.2189" x2="16.6693" y2="35.7907" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint83_linear_603_19788" x1="4.53028" y1="29.3622" x2="4.53028" y2="30.2871" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint84_linear_603_19788" x1="4.53028" y1="27.1718" x2="4.53028" y2="29.8003" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint85_linear_603_19788" x1="7.40203" y1="31.4308" x2="7.40203" y2="34.0958" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint86_linear_603_19788" x1="9.94165" y1="35.3857" x2="9.94165" y2="33.7912" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint87_linear_603_19788" x1="12.2028" y1="1.71576" x2="12.2028" y2="3.69324" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint88_linear_603_19788" x1="8.5934" y1="10.5634" x2="8.5934" y2="6.06595" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint89_linear_603_19788" x1="10.3704" y1="3.8569" x2="10.3704" y2="7.70277" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint90_linear_603_19788" x1="11.4166" y1="3.60159" x2="11.4166" y2="5.26284" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint91_linear_603_19788" x1="9.71341" y1="5.62781" x2="9.71341" y2="8.53019" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint92_linear_603_19788" x1="5.90781" y1="12.6366" x2="5.90781" y2="18.4228" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint93_linear_603_19788" x1="6.4835" y1="11.8886" x2="6.4835" y2="14.827" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint94_linear_603_19788" x1="4.17384" y1="22.9992" x2="4.17384" y2="27.6464" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint95_linear_603_19788" x1="4.21677" y1="25.091" x2="4.21677" y2="30.0068" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint96_linear_603_19788" x1="14.2342" y1="1.1315" x2="14.2342" y2="3.2552" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint97_linear_603_19788" x1="13.5895" y1="1.71576" x2="13.5895" y2="4.89086" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint98_linear_603_19788" x1="13.3618" y1="1.1315" x2="13.3618" y2="3.2552" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint99_linear_603_19788" x1="12.4726" y1="3.81219" x2="12.4726" y2="1.71576" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint100_linear_603_19788" x1="14.0806" y1="11.7424" x2="14.0806" y2="15.0823" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint101_linear_603_19788" x1="13.7861" y1="19.5728" x2="13.7861" y2="23.6154" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint102_linear_603_19788" x1="13.5098" y1="15.3684" x2="13.5098" y2="19.2259" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint103_linear_603_19788" x1="11.098" y1="16.7436" x2="11.098" y2="23.2534" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#641C3B"/>
</linearGradient>
<linearGradient id="paint104_linear_603_19788" x1="11.3718" y1="19.1162" x2="11.3718" y2="15.3684" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint105_linear_603_19788" x1="13.4905" y1="3.76581" x2="13.4905" y2="7.89715" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint106_linear_603_19788" x1="13.9511" y1="8.41586" x2="13.9511" y2="11.4627" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint107_linear_603_19788" x1="12.1629" y1="9.50327" x2="12.1629" y2="14.7481" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint108_linear_603_19788" x1="12.4415" y1="8.41586" x2="12.4415" y2="11.4871" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint109_linear_603_19788" x1="13.9748" y1="28.8266" x2="13.9748" y2="32.2245" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint110_linear_603_19788" x1="6.31119" y1="28.0479" x2="6.31119" y2="31.7714" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint111_linear_603_19788" x1="6.63381" y1="30.287" x2="6.63381" y2="33.7001" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint112_linear_603_19788" x1="5.27818" y1="16.3241" x2="5.27818" y2="22.5663" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint113_linear_603_19788" x1="5.4331" y1="15.1375" x2="5.4331" y2="18.8244" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint114_linear_603_19788" x1="8.20763" y1="8.49368" x2="8.20763" y2="11.4141" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint115_linear_603_19788" x1="5.56131" y1="19.2137" x2="5.56131" y2="23.2534" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint116_linear_603_19788" x1="5.56131" y1="20.8929" x2="5.56131" y2="27.4515" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint117_linear_603_19788" x1="9.50129" y1="32.0197" x2="9.50129" y2="34.3998" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint118_linear_603_19788" x1="9.50129" y1="33.4506" x2="9.50129" y2="35.2099" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint119_linear_603_19788" x1="10.6112" y1="31.0171" x2="10.6112" y2="34.2293" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint120_linear_603_19788" x1="10.6112" y1="32.1972" x2="10.6112" y2="28.5713" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint121_linear_603_19788" x1="8.88959" y1="28.5713" x2="8.88959" y2="31.7713" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint122_linear_603_19788" x1="12.3693" y1="3.45596" x2="12.3693" y2="5.06208" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint123_linear_603_19788" x1="11.8352" y1="3.76581" x2="11.8352" y2="7.89715" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint124_linear_603_19788" x1="10.4456" y1="5.36612" x2="10.4456" y2="8.15594" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint125_linear_603_19788" x1="9.62717" y1="5.97479" x2="9.62717" y2="11.2573" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint126_linear_603_19788" x1="10.1246" y1="8.40195" x2="10.1246" y2="11.414" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint127_linear_603_19788" x1="8.90302" y1="9.47891" x2="8.90302" y2="14.6448" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint128_linear_603_19788" x1="7.62951" y1="11.7424" x2="7.62951" y2="14.979" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint129_linear_603_19788" x1="7.39222" y1="12.7405" x2="7.39222" y2="18.5325" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint130_linear_603_19788" x1="12.6554" y1="5.30865" x2="12.6554" y2="8.15592" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint131_linear_603_19788" x1="12.3177" y1="5.8895" x2="12.3177" y2="11.1645" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#732144"/>
</linearGradient>
<linearGradient id="paint132_linear_603_19788" x1="11.3431" y1="11.7575" x2="11.3431" y2="15.0823" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint133_linear_603_19788" x1="11.1916" y1="12.8008" x2="11.1916" y2="18.7785" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint134_linear_603_19788" x1="8.30367" y1="15.3383" x2="8.30367" y2="19.1162" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint135_linear_603_19788" x1="8.30367" y1="16.5701" x2="8.30367" y2="22.9586" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint136_linear_603_19788" x1="7.52056" y1="23.6519" x2="7.52056" y2="28.2788" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint137_linear_603_19788" x1="7.52056" y1="25.8151" x2="7.52056" y2="31.4731" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint138_linear_603_19788" x1="13.3009" y1="23.999" x2="13.3009" y2="28.5162" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint139_linear_603_19788" x1="10.8509" y1="28.3032" x2="10.8509" y2="23.999" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint140_linear_603_19788" x1="11.0517" y1="26.2346" x2="11.0517" y2="31.9477" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint141_linear_603_19788" x1="10.2702" y1="19.4452" x2="10.2702" y2="23.5882" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint142_linear_603_19788" x1="10.2702" y1="21.3554" x2="10.2702" y2="27.9777" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint143_linear_603_19788" x1="8.54757" y1="19.4452" x2="8.54757" y2="23.3143" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint144_linear_603_19788" x1="12.354" y1="35.641" x2="12.354" y2="34.542" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint145_linear_603_19788" x1="12.354" y1="35.5191" x2="12.354" y2="36.2537" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint146_linear_603_19788" x1="13.6903" y1="32.4653" x2="13.6903" y2="34.5461" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint147_linear_603_19788" x1="12.1015" y1="34.3813" x2="12.1015" y2="32.4653" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint148_linear_603_19788" x1="12.658" y1="33.9861" x2="12.658" y2="35.489" gradientUnits="userSpaceOnUse">
<stop stop-color="#9A2F5B"/>
<stop offset="1" stop-color="#702042"/>
</linearGradient>
<linearGradient id="paint149_linear_603_19788" x1="14.153" y1="36.2189" x2="14.153" y2="35.7907" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint150_linear_603_19788" x1="13.6615" y1="36.2189" x2="13.6615" y2="35.7907" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint151_linear_603_19788" x1="46.435" y1="12.8075" x2="46.435" y2="23.9921" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="0.43" stop-color="#FEFCFD"/>
<stop offset="0.62" stop-color="#FBF5F7"/>
<stop offset="0.77" stop-color="#F7E8ED"/>
<stop offset="0.89" stop-color="#F1D6DF"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint152_linear_603_19788" x1="57.2255" y1="12.9963" x2="57.2255" y2="23.8033" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="0.43" stop-color="#FEFCFD"/>
<stop offset="0.62" stop-color="#FBF5F7"/>
<stop offset="0.77" stop-color="#F7E8ED"/>
<stop offset="0.89" stop-color="#F1D6DF"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint153_linear_603_19788" x1="67.9521" y1="12.9963" x2="67.9521" y2="23.8033" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="0.43" stop-color="#FEFCFD"/>
<stop offset="0.62" stop-color="#FBF5F7"/>
<stop offset="0.77" stop-color="#F7E8ED"/>
<stop offset="0.89" stop-color="#F1D6DF"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint154_linear_603_19788" x1="78.914" y1="12.9963" x2="78.914" y2="23.8033" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="0.43" stop-color="#FEFCFD"/>
<stop offset="0.62" stop-color="#FBF5F7"/>
<stop offset="0.77" stop-color="#F7E8ED"/>
<stop offset="0.89" stop-color="#F1D6DF"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint155_linear_603_19788" x1="86.2527" y1="12.9963" x2="86.2527" y2="23.8033" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="0.43" stop-color="#FEFCFD"/>
<stop offset="0.62" stop-color="#FBF5F7"/>
<stop offset="0.77" stop-color="#F7E8ED"/>
<stop offset="0.89" stop-color="#F1D6DF"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint156_linear_603_19788" x1="93.3544" y1="12.9963" x2="93.3544" y2="23.8033" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="0.43" stop-color="#FEFCFD"/>
<stop offset="0.62" stop-color="#FBF5F7"/>
<stop offset="0.77" stop-color="#F7E8ED"/>
<stop offset="0.89" stop-color="#F1D6DF"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint157_linear_603_19788" x1="104.081" y1="12.9963" x2="104.081" y2="23.8033" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="0.43" stop-color="#FEFCFD"/>
<stop offset="0.62" stop-color="#FBF5F7"/>
<stop offset="0.77" stop-color="#F7E8ED"/>
<stop offset="0.89" stop-color="#F1D6DF"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint158_linear_603_19788" x1="115.554" y1="-90.7762" x2="115.554" y2="-90.7762" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="0.43" stop-color="#FEFCFD"/>
<stop offset="0.62" stop-color="#FBF5F7"/>
<stop offset="0.77" stop-color="#F7E8ED"/>
<stop offset="0.89" stop-color="#F1D6DF"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
<linearGradient id="paint159_linear_603_19788" x1="126.762" y1="12.9963" x2="126.762" y2="23.8033" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="0.43" stop-color="#FEFCFD"/>
<stop offset="0.62" stop-color="#FBF5F7"/>
<stop offset="0.77" stop-color="#F7E8ED"/>
<stop offset="0.89" stop-color="#F1D6DF"/>
<stop offset="1" stop-color="#E9BFCD"/>
</linearGradient>
</defs>
</svg>
);

export default Logo;
