import React from 'react';

export const SentienceExtensionImage = () => (
  <svg width="400" height="300" viewBox="0 0 467 300" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g id="Layer_1">
  <path id="Back" d="M136.52 115.506L132.011 109.798L135.392 93.8481L129.417 88.9246L129.756 75.0748L124.881 72.1367L123.613 58.3696L117.751 54.9538L116.287 43.7058L111.777 41.1333L108.679 28.036L102.817 26.1333L99.8318 17.9087L96.3354 16.844L91.404 8.1418L86.1932 5.2037L80.4018 0L74.6104 5.2037L69.3969 8.00303L64.5515 16.9L60.8885 17.8527L57.8437 26.1333L52.1517 27.8972L48.8274 41.2454L44.2051 43.8179L42.9689 54.847L37.2178 58.3135L35.9762 72.0806L30.9615 75.2135L31.4694 88.7005L25.4953 93.9042L28.8197 109.686L24.4795 115.394L30.3407 127.427L26.96 135.037L31.8081 139.179L38.5131 144.719L35.1888 149.867L51.3348 157.365L49.5584 160.221L68.2144 165.825L80.4018 169.958L92.5892 165.825L111.552 160.333L109.633 157.259L125.698 149.979L122.317 144.746L129.248 139.011L133.927 134.813L130.546 127.259L136.52 115.506Z" fill="url(#paint0_linear_251_22138)"/>
  <g id="Group" filter="url(#filter0_d_251_22138)">
  <path id="Vector" d="M126.531 86.0693L135.717 93.8481L129.178 104.314L126.531 86.0693Z" fill="url(#paint1_linear_251_22138)"/>
  <path id="Vector_2" d="M129.179 104.314L131.208 115.786L135.717 93.8481L129.179 104.314Z" fill="url(#paint2_linear_251_22138)"/>
  <path id="Vector_3" d="M34.4688 86.0693L25.2832 93.8481L31.8217 104.314L34.4688 86.0693Z" fill="url(#paint3_linear_251_22138)"/>
  <path id="Vector_4" d="M31.8217 104.314L29.7927 115.786L25.2832 93.8481L31.8217 104.314Z" fill="url(#paint4_linear_251_22138)"/>
  <path id="Vector_5" d="M125.15 137.052L134.363 135.037L129.504 139.291L125.15 137.052Z" fill="url(#paint5_linear_251_22138)"/>
  <path id="Vector_6" d="M134.363 135.037L129.743 124.964L125.15 137.052L134.363 135.037Z" fill="url(#paint6_linear_251_22138)"/>
  <path id="Vector_7" d="M102.466 160.781L126.193 150.035L106.72 156.808L102.466 160.781Z" fill="#641C3B"/>
  <path id="Vector_8" d="M122.586 144.551L126.193 150.035L106.72 156.808L122.586 144.551Z" fill="url(#paint7_linear_251_22138)"/>
  <path id="Vector_9" d="M112.047 160.501L92.6865 165.825L97.3384 162.74L112.047 160.501Z" fill="#641C3B"/>
  <path id="Vector_10" d="M112.046 160.501L108.383 155.407L97.3379 162.74L112.046 160.501Z" fill="url(#paint8_linear_251_22138)"/>
  <path id="Vector_11" d="M96.7655 16.9854L91.6729 7.89096L95.5615 16.5638L96.7655 16.9854Z" fill="url(#paint9_linear_251_22138)"/>
  <path id="Vector_12" d="M114.051 48.5812L108.918 27.8972L107.819 39.2306L114.051 48.5812Z" fill="url(#paint10_linear_251_22138)"/>
  <path id="Vector_13" d="M100.163 17.738L106.637 35.4252L98.7734 24.2039L100.163 17.738Z" fill="url(#paint11_linear_251_22138)"/>
  <path id="Vector_14" d="M100.162 17.738L95.5615 16.5638L98.773 24.2039L100.162 17.738Z" fill="url(#paint12_linear_251_22138)"/>
  <path id="Vector_15" d="M102.578 25.8824L108.918 27.8972L107.819 39.2306L102.578 25.8824Z" fill="url(#paint13_linear_251_22138)"/>
  <path id="Vector_16" d="M120.334 68.1899L126.418 84.727L123.795 58.116L120.334 68.1899Z" fill="url(#paint14_linear_251_22138)"/>
  <path id="Vector_17" d="M117.625 54.6763L123.795 58.1161L120.334 68.1899L117.625 54.6763Z" fill="url(#paint15_linear_251_22138)"/>
  <path id="Vector_18" d="M125.967 127.147L129.436 105.774L136.843 115.394L125.967 127.147Z" fill="url(#paint16_linear_251_22138)"/>
  <path id="Vector_19" d="M125.967 127.147L125.572 138.002L136.843 115.394L125.967 127.147Z" fill="url(#paint17_linear_251_22138)"/>
  <path id="Vector_20" d="M86.29 5.2037L91.6729 7.89095L95.5616 16.5638L91.337 9.43071L86.29 5.2037Z" fill="white"/>
  <path id="Vector_21" d="M80.499 5.2037L83.7562 14.9707L80.499 8.1418V5.2037Z" fill="url(#paint18_linear_251_22138)"/>
  <path id="Vector_22" d="M80.499 22.3839L83.7562 14.9706L80.499 8.14178V22.3839Z" fill="url(#paint19_linear_251_22138)"/>
  <path id="Vector_23" d="M83.4443 5.2037L86.1774 7.89095L84.9385 14.9707L84.5999 9.37467L83.4443 5.2037Z" fill="url(#paint20_linear_251_22138)"/>
  <path id="Vector_24" d="M90.6546 22.4934L86.1774 7.89096L84.9385 14.9707L90.6546 22.4934Z" fill="white"/>
  <path id="Vector_25" d="M86.1774 7.89096L84.9385 14.9707L90.6546 22.4934L86.1774 7.89096Z" fill="url(#paint21_linear_251_22138)"/>
  <path id="Vector_26" d="M90.6576 14.9707L90.655 22.4934L86.1777 7.89096L90.6576 14.9707Z" fill="#9A2F5B"/>
  <path id="Vector_27" d="M86.29 5.2037L90.5469 7.89095L91.4203 14.9707L89.4182 9.37467L86.29 5.2037Z" fill="url(#paint22_linear_251_22138)"/>
  <path id="Vector_28" d="M95.395 17.319L90.5469 7.89096L91.4203 14.9707L93.4278 17.5325L95.395 17.319Z" fill="url(#paint23_linear_251_22138)"/>
  <path id="Vector_29" d="M81.1895 23.5314L84.6562 15.894L85.9677 17.319L81.1895 23.5314Z" fill="url(#paint24_linear_251_22138)"/>
  <path id="Vector_30" d="M80.499 24.4147L87.1934 37.5094L80.499 27.3101V24.4147Z" fill="url(#paint25_linear_251_22138)"/>
  <path id="Vector_31" d="M81.1895 23.5314L87.8677 36.3192L85.9677 17.319L81.1895 23.5314Z" fill="url(#paint26_linear_251_22138)"/>
  <path id="Vector_32" d="M80.499 51.3459L87.1934 37.5094L80.499 27.3101V51.3459Z" fill="url(#paint27_linear_251_22138)"/>
  <path id="Vector_33" d="M80.499 59.1248V54.0038L90.5472 69.3641L80.499 59.1248Z" fill="url(#paint28_linear_251_22138)"/>
  <path id="Vector_34" d="M80.499 59.1248V86.7417L90.5472 69.364L80.499 59.1248Z" fill="url(#paint29_linear_251_22138)"/>
  <path id="Vector_35" d="M80.499 90.0161V99.0812L93.2803 108.608L80.499 90.0161Z" fill="url(#paint30_linear_251_22138)"/>
  <path id="Vector_36" d="M80.499 99.0812L93.2803 108.608L85.5245 118.081L80.499 129.554V99.0812Z" fill="url(#paint31_linear_251_22138)"/>
  <path id="Vector_37" d="M81.6406 88.4203L94.688 77.0042L91.8689 70.6797L81.6406 88.4203Z" fill="url(#paint32_linear_251_22138)"/>
  <path id="Vector_38" d="M94.4058 106.943L81.6406 88.4203L94.688 77.0042L94.4058 106.943Z" fill="url(#paint33_linear_251_22138)"/>
  <path id="Vector_39" d="M94.4062 106.943L104.269 87.9159L94.6884 77.0042L94.4062 106.943Z" fill="#9A2F5B"/>
  <path id="Vector_40" d="M104.269 87.9159L94.6882 77.0042L91.8691 70.6797L104.269 87.9159Z" fill="url(#paint34_linear_251_22138)"/>
  <path id="Vector_41" d="M90.5471 23.5314L87.8678 36.3192L85.9678 17.319L90.5471 23.5314Z" fill="#9A2F5B"/>
  <path id="Vector_42" d="M81.501 52.7175L88.1658 38.7049L90.743 43.7058L81.501 52.7175Z" fill="url(#paint35_linear_251_22138)"/>
  <path id="Vector_43" d="M90.743 43.7058L81.501 52.7175L91.5331 67.827L90.743 43.7058Z" fill="url(#paint36_linear_251_22138)"/>
  <path id="Vector_44" d="M98.069 52.8296L91.5333 67.827L90.7432 43.7058L98.069 52.8296Z" fill="#9A2F5B"/>
  <path id="Vector_45" d="M98.0691 52.8296L88.166 38.7049L90.7432 43.7058L98.0691 52.8296Z" fill="url(#paint37_linear_251_22138)"/>
  <path id="Vector_46" d="M80.499 144.215V132.574L91.5281 148.201L80.499 144.215Z" fill="url(#paint38_linear_251_22138)"/>
  <path id="Vector_47" d="M80.499 158.374L85.6293 152.066L91.5281 148.202L80.499 144.215V158.374Z" fill="url(#paint39_linear_251_22138)"/>
  <path id="Vector_48" d="M80.499 159.185V164.264L85.46 164.013L80.499 159.185Z" fill="url(#paint40_linear_251_22138)"/>
  <path id="Vector_49" d="M85.46 164.013L82.4151 165.187L80.499 167.159V164.264L85.46 164.013Z" fill="url(#paint41_linear_251_22138)"/>
  <path id="Vector_50" d="M125.12 128.993L129.504 139.291L113.511 146.117L125.12 128.993Z" fill="url(#paint42_linear_251_22138)"/>
  <path id="Vector_51" d="M110.525 154.988L129.504 139.291L113.511 146.117L113.963 148.805L110.525 154.988Z" fill="url(#paint43_linear_251_22138)"/>
  <path id="Vector_52" d="M130.137 75.0748L129.122 103.783L122.443 86.5736L130.137 75.0748Z" fill="url(#paint44_linear_251_22138)"/>
  <path id="Vector_53" d="M122.444 86.5736L130.138 75.0748L121.006 69.6176L122.444 86.5736Z" fill="url(#paint45_linear_251_22138)"/>
  <path id="Vector_54" d="M116.865 43.7058L118.555 58.3696L113.146 55.0098L111.794 52.4934L116.865 43.7058Z" fill="#9A2F5B"/>
  <path id="Vector_55" d="M111.793 52.4934L116.864 43.7058L108.579 39.0625L111.793 52.4934Z" fill="url(#paint46_linear_251_22138)"/>
  <path id="Vector_56" d="M118.978 106.943L122.444 88.3642L130.982 96.0871L118.978 106.943Z" fill="url(#paint47_linear_251_22138)"/>
  <path id="Vector_57" d="M118.978 106.943L123.036 115.394L125.685 126.25L130.982 96.0871L118.978 106.943Z" fill="url(#paint48_linear_251_22138)"/>
  <path id="Vector_58" d="M112.302 147.26L98.4912 158.206L114.976 153.84L112.302 147.26Z" fill="url(#paint49_linear_251_22138)"/>
  <path id="Vector_59" d="M98.6632 161.931L100.098 158.988L98.4912 158.206L114.976 153.84L98.6632 161.931Z" fill="url(#paint50_linear_251_22138)"/>
  <path id="Vector_60" d="M93.6162 148.076L109.566 142.648L98.2385 157.421L96.8868 151.743L93.6162 148.076Z" fill="url(#paint51_linear_251_22138)"/>
  <path id="Vector_61" d="M111.99 146.117L109.566 142.648L98.2383 157.421L107.367 149.474L111.99 146.117Z" fill="#9A2F5B"/>
  <path id="Vector_62" d="M93.6162 148.076L109.566 142.648L107.145 131.4L93.6162 148.076Z" fill="url(#paint52_linear_251_22138)"/>
  <path id="Vector_63" d="M111.99 146.117L109.566 142.648L107.145 131.4L111.99 146.117Z" fill="url(#paint53_linear_251_22138)"/>
  <path id="Vector_64" d="M91.5039 23.2806L91.5335 15.894L95.3953 17.319L91.5039 23.2806Z" fill="url(#paint54_linear_251_22138)"/>
  <path id="Vector_65" d="M91.5039 23.2806L100.337 36.3192L95.3953 17.319L91.5039 23.2806Z" fill="url(#paint55_linear_251_22138)"/>
  <path id="Vector_66" d="M98.3087 24.2466L100.338 36.3192L95.3955 17.319L98.3087 24.2466Z" fill="#9A2F5B"/>
  <path id="Vector_67" d="M98.9717 24.6789L105.747 27.4782L101.366 37.5094L98.9717 24.6789Z" fill="url(#paint56_linear_251_22138)"/>
  <path id="Vector_68" d="M110.933 51.7729L105.747 27.4782L101.366 37.5094L110.933 51.7729Z" fill="url(#paint57_linear_251_22138)"/>
  <path id="Vector_69" d="M101.227 38.6408L99.6201 52.4934L108.075 43.5937L101.227 38.6408Z" fill="url(#paint58_linear_251_22138)"/>
  <path id="Vector_70" d="M110.187 67.3519L99.6201 52.4934L108.075 43.5937L110.187 67.3519Z" fill="url(#paint59_linear_251_22138)"/>
  <path id="Vector_71" d="M110.187 67.3519L110.934 51.7728L108.074 43.5937L110.187 67.3519Z" fill="#9A2F5B"/>
  <path id="Vector_72" d="M111.651 54.0038L119.541 58.5937L111.256 68.889L111.651 54.0038Z" fill="url(#paint60_linear_251_22138)"/>
  <path id="Vector_73" d="M121.739 85.2314L119.541 58.5937L111.256 68.889L121.739 85.2314Z" fill="url(#paint61_linear_251_22138)"/>
  <path id="Vector_74" d="M88.8535 37.5094L91.42 24.4147L95.3947 27.0859L88.8535 37.5094Z" fill="url(#paint62_linear_251_22138)"/>
  <path id="Vector_75" d="M95.3947 27.0859L88.8535 37.5094L98.5201 51.3459L95.3947 27.0859Z" fill="url(#paint63_linear_251_22138)"/>
  <path id="Vector_76" d="M95.3955 27.0859L100.356 37.6321L98.521 51.3459L95.3955 27.0859Z" fill="#9A2F5B"/>
  <path id="Vector_77" d="M92.8154 69.3641L99.1738 54.0732L103.592 58.8713L92.8154 69.3641Z" fill="url(#paint64_linear_251_22138)"/>
  <path id="Vector_78" d="M92.8154 69.364L104.987 86.3628L103.592 58.8712L92.8154 69.364Z" fill="url(#paint65_linear_251_22138)"/>
  <path id="Vector_79" d="M109.848 68.889L104.987 86.3628L103.592 58.8712L109.848 68.889Z" fill="#9A2F5B"/>
  <path id="Vector_80" d="M106.172 87.9159L110.934 70.5409L118.386 76.2063L106.172 87.9159Z" fill="url(#paint66_linear_251_22138)"/>
  <path id="Vector_81" d="M118.386 76.2063L106.172 87.9159L117.752 105.587L118.386 76.2063Z" fill="url(#paint67_linear_251_22138)"/>
  <path id="Vector_82" d="M118.386 76.2063L121.684 86.5737L117.752 105.587L118.386 76.2063Z" fill="#9A2F5B"/>
  <path id="Vector_83" d="M108.185 130.055L118.007 108.776L123.629 118.725L108.185 130.055Z" fill="url(#paint68_linear_251_22138)"/>
  <path id="Vector_84" d="M108.185 130.055L112.468 137.191L113.315 144.746L123.629 118.725L108.185 130.055Z" fill="url(#paint69_linear_251_22138)"/>
  <path id="Vector_85" d="M125.15 127.285L118.754 135.344L113.314 144.746L123.629 118.725L125.15 127.285Z" fill="#9A2F5B"/>
  <path id="Vector_86" d="M81.5283 131.147L94.5461 110.372L96.7444 120.654L81.5283 131.147Z" fill="url(#paint70_linear_251_22138)"/>
  <path id="Vector_87" d="M106.411 130.167L94.5459 110.372L96.7442 120.654L106.411 130.167Z" fill="url(#paint71_linear_251_22138)"/>
  <path id="Vector_88" d="M106.411 130.167L97.9565 138.451L92.6865 146.929L96.7445 120.654L106.411 130.167Z" fill="#9A2F5B"/>
  <path id="Vector_89" d="M81.5283 131.147L89.1364 138.757L92.6864 146.929L96.7444 120.654L81.5283 131.147Z" fill="url(#paint72_linear_251_22138)"/>
  <path id="Vector_90" d="M95.6445 108.483L105.394 89.429L110.694 98.2139L95.6445 108.483Z" fill="url(#paint73_linear_251_22138)"/>
  <path id="Vector_91" d="M95.6445 108.483L103.339 118.346L107.48 128.67L110.694 98.2139L95.6445 108.483Z" fill="url(#paint74_linear_251_22138)"/>
  <path id="Vector_92" d="M116.908 107.223L111.025 117.041L107.48 128.67L110.695 98.2139L116.908 107.223Z" fill="#9A2F5B"/>
  <path id="Vector_93" d="M116.907 107.223L105.395 89.429L110.694 98.2139L116.907 107.223Z" fill="url(#paint75_linear_251_22138)"/>
  <path id="Vector_94" d="M87.8408 163.914L97.3973 158.86L99.1978 163.354L87.8408 163.914Z" fill="url(#paint76_linear_251_22138)"/>
  <path id="Vector_95" d="M87.8408 163.914L89.6172 164.643L89.077 166.732L99.1978 163.354L87.8408 163.914Z" fill="url(#paint77_linear_251_22138)"/>
  <path id="Vector_96" d="M81.2754 158.878L92.2642 149.309L93.3929 156.303L81.2754 158.878Z" fill="url(#paint78_linear_251_22138)"/>
  <path id="Vector_97" d="M97.1127 158.121L92.2646 149.309L93.3934 156.303L97.1127 158.121Z" fill="url(#paint79_linear_251_22138)"/>
  <path id="Vector_98" d="M97.1126 158.121L92.321 159.858L87.1074 163.215L93.3933 156.303L97.1126 158.121Z" fill="#9A2F5B"/>
  <path id="Vector_99" d="M81.2754 158.878L85.1076 160.333L87.1071 163.215L93.3929 156.303L81.2754 158.878Z" fill="url(#paint80_linear_251_22138)"/>
  <path id="Vector_100" d="M82.9229 165.825L86.4272 164.603L87.4458 166.572L82.9229 165.825Z" fill="url(#paint81_linear_251_22138)"/>
  <path id="Vector_101" d="M87.4458 166.572L82.9229 165.825L84.1913 166.471L84.065 167.119L87.4458 166.572Z" fill="#641C3B"/>
  <path id="Vector_102" d="M88.5014 165.825L86.4268 164.603L87.4453 166.572L88.5014 165.825Z" fill="url(#paint82_linear_251_22138)"/>
  <path id="Vector_103" d="M35.8499 137.052L26.6348 135.037L31.4963 139.291L35.8499 137.052Z" fill="url(#paint83_linear_251_22138)"/>
  <path id="Vector_104" d="M26.6348 135.037L31.2571 124.964L35.8499 137.052L26.6348 135.037Z" fill="url(#paint84_linear_251_22138)"/>
  <path id="Vector_105" d="M58.5347 160.781L34.8076 150.035L54.2806 156.808L58.5347 160.781Z" fill="#641C3B"/>
  <path id="Vector_106" d="M38.4141 144.551L34.8076 150.035L54.2806 156.808L38.4141 144.551Z" fill="url(#paint85_linear_251_22138)"/>
  <path id="Vector_107" d="M48.9541 160.501L68.3142 165.825L63.6623 162.74L48.9541 160.501Z" fill="#641C3B"/>
  <path id="Vector_108" d="M48.9541 160.501L52.617 155.407L63.6623 162.74L48.9541 160.501Z" fill="url(#paint86_linear_251_22138)"/>
  <path id="Vector_109" d="M64.2344 16.9854L69.327 7.89096L65.4383 16.5638L64.2344 16.9854Z" fill="url(#paint87_linear_251_22138)"/>
  <path id="Vector_110" d="M46.9492 48.5812L52.0822 27.8972L53.1813 39.2306L46.9492 48.5812Z" fill="url(#paint88_linear_251_22138)"/>
  <path id="Vector_111" d="M60.8373 17.738L54.3633 35.4252L62.2266 24.2039L60.8373 17.738Z" fill="url(#paint89_linear_251_22138)"/>
  <path id="Vector_112" d="M60.8379 17.738L65.4387 16.5638L62.2273 24.2039L60.8379 17.738Z" fill="url(#paint90_linear_251_22138)"/>
  <path id="Vector_113" d="M58.4216 25.8824L52.082 27.8972L53.1812 39.2306L58.4216 25.8824Z" fill="url(#paint91_linear_251_22138)"/>
  <path id="Vector_114" d="M40.6663 68.1899L34.582 84.727L37.2049 58.116L40.6663 68.1899Z" fill="url(#paint92_linear_251_22138)"/>
  <path id="Vector_115" d="M43.3754 54.6763L37.2051 58.1161L40.6665 68.1899L43.3754 54.6763Z" fill="url(#paint93_linear_251_22138)"/>
  <path id="Vector_116" d="M35.0332 127.147L31.5637 105.774L24.1572 115.394L35.0332 127.147Z" fill="url(#paint94_linear_251_22138)"/>
  <path id="Vector_117" d="M35.0332 127.147L35.4282 138.002L24.1572 115.394L35.0332 127.147Z" fill="url(#paint95_linear_251_22138)"/>
  <path id="Vector_118" d="M74.71 5.2037L69.3272 7.89095L65.4385 16.5638L69.6631 9.43071L74.71 5.2037Z" fill="white"/>
  <path id="Vector_119" d="M80.4986 5.2037L77.2441 14.9707L80.4986 8.1418V5.2037Z" fill="white"/>
  <path id="Vector_120" d="M80.4986 22.3839L77.2441 14.9706L80.4986 8.14178V22.3839Z" fill="#9A2F5B"/>
  <path id="Vector_121" d="M77.5563 5.2037L74.8232 7.89095L76.0621 14.9707L76.4007 9.37467L77.5563 5.2037Z" fill="url(#paint96_linear_251_22138)"/>
  <path id="Vector_122" d="M70.3457 22.4934L74.8229 7.89096L76.0618 14.9707L70.3457 22.4934Z" fill="white"/>
  <path id="Vector_123" d="M74.8229 7.89096L76.0618 14.9707L70.3457 22.4934L74.8229 7.89096Z" fill="url(#paint97_linear_251_22138)"/>
  <path id="Vector_124" d="M70.3408 14.9707L70.3462 22.4934L74.8234 7.89096L70.3408 14.9707Z" fill="#9A2F5B"/>
  <path id="Vector_125" d="M74.7103 5.2037L70.4535 7.89095L69.5801 14.9707L71.5822 9.37467L74.7103 5.2037Z" fill="url(#paint98_linear_251_22138)"/>
  <path id="Vector_126" d="M65.6055 17.319L70.4536 7.89096L69.5801 14.9707L67.5727 17.5325L65.6055 17.319Z" fill="url(#paint99_linear_251_22138)"/>
  <path id="Vector_127" d="M79.8104 23.5314L76.3437 15.894L75.0322 17.319L79.8104 23.5314Z" fill="white"/>
  <path id="Vector_128" d="M80.4983 24.4147L73.8066 37.5094L80.4983 27.3101V24.4147Z" fill="white"/>
  <path id="Vector_129" d="M79.811 23.5314L73.1328 36.3192L75.0328 17.319L79.811 23.5314Z" fill="#9A2F5B"/>
  <path id="Vector_130" d="M80.4983 51.3459L73.8066 37.5094L80.4983 27.3101V51.3459Z" fill="#9A2F5B"/>
  <path id="Vector_131" d="M80.4987 59.1248V54.0038L70.4531 69.3641L80.4987 59.1248Z" fill="url(#paint100_linear_251_22138)"/>
  <path id="Vector_132" d="M80.4987 59.1248V86.7417L70.4531 69.364L80.4987 59.1248Z" fill="#9A2F5B"/>
  <path id="Vector_133" d="M80.4984 90.0161V99.0812L67.7197 108.608L80.4984 90.0161Z" fill="url(#paint101_linear_251_22138)"/>
  <path id="Vector_134" d="M80.4984 99.0812L67.7197 108.608L75.4756 118.081L80.4984 129.554V99.0812Z" fill="#9A2F5B"/>
  <path id="Vector_135" d="M79.3589 88.4203L66.3115 77.0042L69.1306 70.6797L79.3589 88.4203Z" fill="url(#paint102_linear_251_22138)"/>
  <path id="Vector_136" d="M66.5937 106.943L79.3589 88.4203L66.3115 77.0042L66.5937 106.943Z" fill="#9A2F5B"/>
  <path id="Vector_137" d="M66.5942 106.943L56.7314 87.9159L66.3121 77.0042L66.5942 106.943Z" fill="url(#paint103_linear_251_22138)"/>
  <path id="Vector_138" d="M56.7314 87.9159L66.3121 77.0042L69.1311 70.6797L56.7314 87.9159Z" fill="url(#paint104_linear_251_22138)"/>
  <path id="Vector_139" d="M70.4531 23.5314L73.1325 36.3192L75.0325 17.319L70.4531 23.5314Z" fill="url(#paint105_linear_251_22138)"/>
  <path id="Vector_140" d="M79.4988 52.7175L72.8341 38.7049L70.2568 43.7058L79.4988 52.7175Z" fill="url(#paint106_linear_251_22138)"/>
  <path id="Vector_141" d="M70.2569 43.7058L79.4989 52.7175L69.4668 67.827L70.2569 43.7058Z" fill="#9A2F5B"/>
  <path id="Vector_142" d="M62.9316 52.8296L69.4674 67.827L70.2575 43.7058L62.9316 52.8296Z" fill="url(#paint107_linear_251_22138)"/>
  <path id="Vector_143" d="M62.9316 52.8296L72.8347 38.7049L70.2575 43.7058L62.9316 52.8296Z" fill="url(#paint108_linear_251_22138)"/>
  <path id="Vector_144" d="M80.4991 144.215V132.574L69.4727 148.201L80.4991 144.215Z" fill="url(#paint109_linear_251_22138)"/>
  <path id="Vector_145" d="M80.4991 158.374L75.3715 152.066L69.4727 148.202L80.4991 144.215V158.374Z" fill="#9A2F5B"/>
  <path id="Vector_146" d="M80.4983 159.185V164.264L75.54 164.013L80.4983 159.185Z" fill="white"/>
  <path id="Vector_147" d="M75.54 164.013L78.5822 165.187L80.4983 167.159V164.264L75.54 164.013Z" fill="#9A2F5B"/>
  <path id="Vector_148" d="M35.8793 128.993L31.4961 139.291L47.4889 146.117L35.8793 128.993Z" fill="url(#paint110_linear_251_22138)"/>
  <path id="Vector_149" d="M50.4746 154.988L31.4961 139.291L47.4889 146.117L47.0374 148.805L50.4746 154.988Z" fill="url(#paint111_linear_251_22138)"/>
  <path id="Vector_150" d="M30.8623 75.0748L31.8781 103.783L38.5564 86.5736L30.8623 75.0748Z" fill="url(#paint112_linear_251_22138)"/>
  <path id="Vector_151" d="M38.5564 86.5736L30.8623 75.0748L39.9941 69.6176L38.5564 86.5736Z" fill="url(#paint113_linear_251_22138)"/>
  <path id="Vector_152" d="M44.1357 43.7058L42.4453 58.3696L47.8551 55.0098L49.2068 52.4934L44.1357 43.7058Z" fill="#9A2F5B"/>
  <path id="Vector_153" d="M49.2069 52.4934L44.1357 43.7058L52.421 39.0625L49.2069 52.4934Z" fill="url(#paint114_linear_251_22138)"/>
  <path id="Vector_154" d="M42.0232 106.943L38.5565 88.3642L30.0186 96.0871L42.0232 106.943Z" fill="url(#paint115_linear_251_22138)"/>
  <path id="Vector_155" d="M42.0232 106.943L37.9652 115.394L35.3154 126.25L30.0186 96.0871L42.0232 106.943Z" fill="url(#paint116_linear_251_22138)"/>
  <path id="Vector_156" d="M48.6984 147.26L62.509 158.206L46.0244 153.84L48.6984 147.26Z" fill="url(#paint117_linear_251_22138)"/>
  <path id="Vector_157" d="M62.337 161.931L60.9019 158.988L62.509 158.206L46.0244 153.84L62.337 161.931Z" fill="url(#paint118_linear_251_22138)"/>
  <path id="Vector_158" d="M67.3817 148.076L51.4346 142.648L62.762 157.421L64.1138 151.743L67.3817 148.076Z" fill="url(#paint119_linear_251_22138)"/>
  <path id="Vector_159" d="M49.0107 146.117L51.4348 142.648L62.7622 157.421L53.6331 149.474L49.0107 146.117Z" fill="#9A2F5B"/>
  <path id="Vector_160" d="M67.3817 148.076L51.4346 142.648L53.8559 131.4L67.3817 148.076Z" fill="url(#paint120_linear_251_22138)"/>
  <path id="Vector_161" d="M49.0107 146.117L51.4348 142.648L53.8561 131.4L49.0107 146.117Z" fill="url(#paint121_linear_251_22138)"/>
  <path id="Vector_162" d="M69.4968 23.2806L69.4673 15.894L65.6055 17.319L69.4968 23.2806Z" fill="url(#paint122_linear_251_22138)"/>
  <path id="Vector_163" d="M69.4966 23.2806L60.6631 36.3192L65.6052 17.319L69.4966 23.2806Z" fill="url(#paint123_linear_251_22138)"/>
  <path id="Vector_164" d="M62.6921 24.2466L60.6631 36.3192L65.6052 17.319L62.6921 24.2466Z" fill="#9A2F5B"/>
  <path id="Vector_165" d="M62.0286 24.6789L55.251 27.4782L59.6341 37.5094L62.0286 24.6789Z" fill="url(#paint124_linear_251_22138)"/>
  <path id="Vector_166" d="M50.0635 51.7729L55.2502 27.4782L59.6333 37.5094L50.0635 51.7729Z" fill="url(#paint125_linear_251_22138)"/>
  <path id="Vector_167" d="M59.7733 38.6408L61.3804 52.4934L52.9258 43.5937L59.7733 38.6408Z" fill="url(#paint126_linear_251_22138)"/>
  <path id="Vector_168" d="M50.8135 67.3519L61.3804 52.4934L52.9258 43.5937L50.8135 67.3519Z" fill="#9A2F5B"/>
  <path id="Vector_169" d="M50.8133 67.3519L50.0635 51.7728L52.9256 43.5937L50.8133 67.3519Z" fill="url(#paint127_linear_251_22138)"/>
  <path id="Vector_170" d="M49.3492 54.0038L41.459 58.5937L49.7443 68.889L49.3492 54.0038Z" fill="url(#paint128_linear_251_22138)"/>
  <path id="Vector_171" d="M39.2607 85.2314L41.459 58.5937L49.7443 68.889L39.2607 85.2314Z" fill="url(#paint129_linear_251_22138)"/>
  <path id="Vector_172" d="M72.1466 37.5094L69.5801 24.4147L65.6055 27.0859L72.1466 37.5094Z" fill="url(#paint130_linear_251_22138)"/>
  <path id="Vector_173" d="M65.6049 27.0859L72.1461 37.5094L62.4795 51.3459L65.6049 27.0859Z" fill="url(#paint131_linear_251_22138)"/>
  <path id="Vector_174" d="M65.6055 27.0859L60.6445 37.6321L62.48 51.3459L65.6055 27.0859Z" fill="#9A2F5B"/>
  <path id="Vector_175" d="M68.1847 69.3641L61.8263 54.0732L57.4082 58.8713L68.1847 69.3641Z" fill="url(#paint132_linear_251_22138)"/>
  <path id="Vector_176" d="M68.185 69.364L56.0137 86.3628L57.4084 58.8712L68.185 69.364Z" fill="url(#paint133_linear_251_22138)"/>
  <path id="Vector_177" d="M51.1523 68.889L56.0139 86.3628L57.4086 58.8712L51.1523 68.889Z" fill="#9A2F5B"/>
  <path id="Vector_178" d="M54.8285 87.9159L50.0638 70.5409L42.6143 76.2063L54.8285 87.9159Z" fill="url(#paint134_linear_251_22138)"/>
  <path id="Vector_179" d="M42.6143 76.2063L54.8285 87.9159L43.2485 105.587L42.6143 76.2063Z" fill="url(#paint135_linear_251_22138)"/>
  <path id="Vector_180" d="M42.6148 76.2063L39.3174 86.5737L43.2491 105.587L42.6148 76.2063Z" fill="#9A2F5B"/>
  <path id="Vector_181" d="M52.8156 130.055L42.9932 108.776L37.3711 118.725L52.8156 130.055Z" fill="url(#paint136_linear_251_22138)"/>
  <path id="Vector_182" d="M52.8156 130.055L48.5319 137.191L47.6854 144.746L37.3711 118.725L52.8156 130.055Z" fill="url(#paint137_linear_251_22138)"/>
  <path id="Vector_183" d="M35.8506 127.285L42.2466 135.344L47.6859 144.746L37.3717 118.725L35.8506 127.285Z" fill="#9A2F5B"/>
  <path id="Vector_184" d="M79.472 131.147L66.4515 110.372L64.2559 120.654L79.472 131.147Z" fill="url(#paint138_linear_251_22138)"/>
  <path id="Vector_185" d="M54.5898 130.167L66.4521 110.372L64.2565 120.654L54.5898 130.167Z" fill="url(#paint139_linear_251_22138)"/>
  <path id="Vector_186" d="M54.5898 130.167L63.0444 138.451L68.3144 146.929L64.2565 120.654L54.5898 130.167Z" fill="url(#paint140_linear_251_22138)"/>
  <path id="Vector_187" d="M79.472 131.147L71.8639 138.757L68.3138 146.929L64.2559 120.654L79.472 131.147Z" fill="#9A2F5B"/>
  <path id="Vector_188" d="M65.3552 108.483L55.6052 89.429L50.3057 98.2139L65.3552 108.483Z" fill="url(#paint141_linear_251_22138)"/>
  <path id="Vector_189" d="M65.3552 108.483L57.6611 118.346L53.5198 128.67L50.3057 98.2139L65.3552 108.483Z" fill="url(#paint142_linear_251_22138)"/>
  <path id="Vector_190" d="M44.0928 107.223L49.9755 117.041L53.5202 128.67L50.3061 98.2139L44.0928 107.223Z" fill="#9A2F5B"/>
  <path id="Vector_191" d="M44.0928 107.223L55.6056 89.429L50.3061 98.2139L44.0928 107.223Z" fill="url(#paint143_linear_251_22138)"/>
  <path id="Vector_192" d="M73.1597 163.914L63.6033 158.86L61.8027 163.354L73.1597 163.914Z" fill="url(#paint144_linear_251_22138)"/>
  <path id="Vector_193" d="M73.1597 163.914L71.3833 164.643L71.9235 166.732L61.8027 163.354L73.1597 163.914Z" fill="url(#paint145_linear_251_22138)"/>
  <path id="Vector_194" d="M79.7249 158.878L68.7361 149.309L67.6074 156.303L79.7249 158.878Z" fill="url(#paint146_linear_251_22138)"/>
  <path id="Vector_195" d="M63.8877 158.121L68.7358 149.309L67.6071 156.303L63.8877 158.121Z" fill="url(#paint147_linear_251_22138)"/>
  <path id="Vector_196" d="M63.8877 158.121L68.6793 159.858L73.8929 163.215L67.6071 156.303L63.8877 158.121Z" fill="url(#paint148_linear_251_22138)"/>
  <path id="Vector_197" d="M79.7249 158.878L75.8927 160.333L73.8933 163.215L67.6074 156.303L79.7249 158.878Z" fill="#9A2F5B"/>
  <path id="Vector_198" d="M78.0776 165.825L74.5732 164.603L73.5547 166.572L78.0776 165.825Z" fill="url(#paint149_linear_251_22138)"/>
  <path id="Vector_199" d="M73.5547 166.572L78.0776 165.825L76.8091 166.471L76.9354 167.119L73.5547 166.572Z" fill="#641C3B"/>
  <path id="Vector_200" d="M72.498 165.825L74.5727 164.603L73.5542 166.572L72.498 165.825Z" fill="url(#paint150_linear_251_22138)"/>
  </g>
  </g>
  <defs>
  <filter id="filter0_d_251_22138" x="21.7372" y="5.1937" width="117.526" height="166.795" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
  <feFlood flood-opacity="0" result="BackgroundImageFix"/>
  <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
  <feOffset dy="2.41"/>
  <feGaussianBlur stdDeviation="1.21"/>
  <feColorMatrix type="matrix" values="0 0 0 0 0.392157 0 0 0 0 0.109804 0 0 0 0 0.231373 0 0 0 0.21 0"/>
  <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_251_22138"/>
  <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_251_22138" result="shape"/>
  </filter>
  <linearGradient id="paint0_linear_251_22138" x1="80.4985" y1="169.958" x2="80.4985" y2="0" gradientUnits="userSpaceOnUse">
  <stop stop-color="#B66285"/>
  <stop offset="1" stop-color="#FFE3EF"/>
  </linearGradient>
  <linearGradient id="paint1_linear_251_22138" x1="131.124" y1="86.0693" x2="131.124" y2="104.314" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint2_linear_251_22138" x1="132.447" y1="93.8481" x2="132.447" y2="115.786" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint3_linear_251_22138" x1="29.876" y1="86.0693" x2="29.876" y2="104.314" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint4_linear_251_22138" x1="28.5538" y1="93.8481" x2="28.5538" y2="115.786" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint5_linear_251_22138" x1="129.757" y1="135.037" x2="129.757" y2="139.291" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint6_linear_251_22138" x1="129.757" y1="124.964" x2="129.757" y2="137.052" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint7_linear_251_22138" x1="116.456" y1="144.551" x2="116.456" y2="156.808" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint8_linear_251_22138" x1="104.691" y1="162.74" x2="104.691" y2="155.407" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint9_linear_251_22138" x1="91.6729" y1="12.4382" x2="96.7655" y2="12.4382" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint10_linear_251_22138" x1="110.934" y1="48.5812" x2="110.934" y2="27.8972" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint11_linear_251_22138" x1="102.705" y1="17.738" x2="102.705" y2="35.4252" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint12_linear_251_22138" x1="97.8619" y1="16.5638" x2="97.8619" y2="24.2039" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint13_linear_251_22138" x1="105.747" y1="25.8824" x2="105.747" y2="39.2306" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint14_linear_251_22138" x1="123.376" y1="58.116" x2="123.376" y2="84.727" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint15_linear_251_22138" x1="120.71" y1="54.6763" x2="120.71" y2="68.1899" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint16_linear_251_22138" x1="131.403" y1="105.774" x2="131.403" y2="127.147" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint17_linear_251_22138" x1="131.208" y1="115.394" x2="131.208" y2="138.002" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint18_linear_251_22138" x1="82.1276" y1="14.9707" x2="82.1276" y2="5.2037" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint19_linear_251_22138" x1="82.1276" y1="8.14178" x2="82.1276" y2="22.3839" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint20_linear_251_22138" x1="84.8122" y1="5.2037" x2="84.8122" y2="14.9707" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint21_linear_251_22138" x1="87.7979" y1="7.89096" x2="87.7979" y2="22.4934" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint22_linear_251_22138" x1="88.8538" y1="5.2037" x2="88.8538" y2="14.9707" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint23_linear_251_22138" x1="92.9709" y1="7.89096" x2="92.9709" y2="17.5325" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint24_linear_251_22138" x1="83.5786" y1="15.894" x2="83.5786" y2="23.5314" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint25_linear_251_22138" x1="83.8475" y1="37.5094" x2="83.8475" y2="24.4147" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint26_linear_251_22138" x1="84.5299" y1="17.319" x2="84.5299" y2="36.3192" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint27_linear_251_22138" x1="83.8475" y1="27.3101" x2="83.8475" y2="51.3459" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint28_linear_251_22138" x1="85.5245" y1="69.3641" x2="85.5245" y2="54.0038" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint29_linear_251_22138" x1="85.5245" y1="59.1248" x2="85.5245" y2="86.7417" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint30_linear_251_22138" x1="86.8897" y1="108.608" x2="86.8897" y2="90.0161" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint31_linear_251_22138" x1="86.8897" y1="99.0812" x2="86.8897" y2="129.554" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint32_linear_251_22138" x1="88.1657" y1="88.4203" x2="88.1657" y2="70.6797" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint33_linear_251_22138" x1="88.1657" y1="77.0042" x2="88.1657" y2="106.943" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#641C3B"/>
  </linearGradient>
  <linearGradient id="paint34_linear_251_22138" x1="98.069" y1="70.6797" x2="98.069" y2="87.9159" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint35_linear_251_22138" x1="86.1206" y1="52.7175" x2="86.1206" y2="38.7049" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint36_linear_251_22138" x1="86.5157" y1="43.7058" x2="86.5157" y2="67.827" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint37_linear_251_22138" x1="93.1162" y1="38.7049" x2="93.1162" y2="52.8296" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#FFE3EF"/>
  </linearGradient>
  <linearGradient id="paint38_linear_251_22138" x1="86.0136" y1="148.201" x2="86.0136" y2="132.574" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint39_linear_251_22138" x1="86.0136" y1="144.215" x2="86.0136" y2="158.374" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint40_linear_251_22138" x1="82.9795" y1="164.264" x2="82.9795" y2="159.185" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint41_linear_251_22138" x1="82.9795" y1="164.013" x2="82.9795" y2="167.159" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint42_linear_251_22138" x1="121.506" y1="128.993" x2="121.506" y2="146.117" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint43_linear_251_22138" x1="120.015" y1="139.291" x2="120.015" y2="154.988" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint44_linear_251_22138" x1="126.289" y1="75.0748" x2="126.289" y2="103.783" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint45_linear_251_22138" x1="125.572" y1="69.6176" x2="125.572" y2="86.5736" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint46_linear_251_22138" x1="112.723" y1="39.0625" x2="112.723" y2="52.4934" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint47_linear_251_22138" x1="124.981" y1="88.3642" x2="124.981" y2="106.943" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint48_linear_251_22138" x1="124.981" y1="96.0871" x2="124.981" y2="126.25" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint49_linear_251_22138" x1="106.733" y1="147.26" x2="106.733" y2="158.206" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint50_linear_251_22138" x1="106.733" y1="153.84" x2="106.733" y2="161.931" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint51_linear_251_22138" x1="101.592" y1="142.648" x2="101.592" y2="157.421" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint52_linear_251_22138" x1="101.592" y1="148.076" x2="101.592" y2="131.4" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint53_linear_251_22138" x1="109.566" y1="131.4" x2="109.566" y2="146.117" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint54_linear_251_22138" x1="93.4496" y1="15.894" x2="93.4496" y2="23.2806" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint55_linear_251_22138" x1="95.922" y1="17.319" x2="95.922" y2="36.3192" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint56_linear_251_22138" x1="102.361" y1="24.6789" x2="102.361" y2="37.5094" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint57_linear_251_22138" x1="106.15" y1="27.4782" x2="106.15" y2="51.7729" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint58_linear_251_22138" x1="103.847" y1="38.6408" x2="103.847" y2="52.4934" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint59_linear_251_22138" x1="104.904" y1="43.5937" x2="104.904" y2="67.3519" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint60_linear_251_22138" x1="115.4" y1="54.0038" x2="115.4" y2="68.889" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint61_linear_251_22138" x1="116.499" y1="58.5937" x2="116.499" y2="85.2314" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint62_linear_251_22138" x1="92.1241" y1="24.4147" x2="92.1241" y2="37.5094" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint63_linear_251_22138" x1="93.6882" y1="27.0859" x2="93.6882" y2="51.3459" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint64_linear_251_22138" x1="98.2037" y1="54.0732" x2="98.2037" y2="69.3641" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint65_linear_251_22138" x1="98.9024" y1="58.8712" x2="98.9024" y2="86.3628" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint66_linear_251_22138" x1="112.278" y1="70.5409" x2="112.278" y2="87.9159" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint67_linear_251_22138" x1="112.278" y1="76.2063" x2="112.278" y2="105.587" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint68_linear_251_22138" x1="115.905" y1="108.776" x2="115.905" y2="130.055" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint69_linear_251_22138" x1="115.905" y1="118.725" x2="115.905" y2="144.746" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint70_linear_251_22138" x1="89.1364" y1="131.147" x2="89.1364" y2="110.372" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint71_linear_251_22138" x1="100.48" y1="110.372" x2="100.48" y2="130.167" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint72_linear_251_22138" x1="89.1364" y1="120.654" x2="89.1364" y2="146.929" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint73_linear_251_22138" x1="103.169" y1="89.429" x2="103.169" y2="108.483" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint74_linear_251_22138" x1="103.169" y1="98.2139" x2="103.169" y2="128.67" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint75_linear_251_22138" x1="111.151" y1="89.429" x2="111.151" y2="107.223" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint76_linear_251_22138" x1="93.5193" y1="163.914" x2="93.5193" y2="158.86" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint77_linear_251_22138" x1="93.5193" y1="163.354" x2="93.5193" y2="166.732" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint78_linear_251_22138" x1="87.3328" y1="158.878" x2="87.3328" y2="149.309" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint79_linear_251_22138" x1="94.6887" y1="149.309" x2="94.6887" y2="158.121" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint80_linear_251_22138" x1="87.3328" y1="156.303" x2="87.3328" y2="163.215" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint81_linear_251_22138" x1="85.1857" y1="166.572" x2="85.1857" y2="164.603" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint82_linear_251_22138" x1="87.4641" y1="166.572" x2="87.4641" y2="164.603" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint83_linear_251_22138" x1="31.2437" y1="135.037" x2="31.2437" y2="139.291" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint84_linear_251_22138" x1="31.2437" y1="124.964" x2="31.2437" y2="137.052" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint85_linear_251_22138" x1="44.5441" y1="144.551" x2="44.5441" y2="156.808" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint86_linear_251_22138" x1="56.3095" y1="162.74" x2="56.3095" y2="155.407" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint87_linear_251_22138" x1="66.7794" y1="7.89096" x2="66.7794" y2="16.9854" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint88_linear_251_22138" x1="50.0639" y1="48.5812" x2="50.0639" y2="27.8972" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint89_linear_251_22138" x1="58.295" y1="17.738" x2="58.295" y2="35.4252" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint90_linear_251_22138" x1="63.1383" y1="16.5638" x2="63.1383" y2="24.2039" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint91_linear_251_22138" x1="55.2505" y1="25.8824" x2="55.2505" y2="39.2306" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint92_linear_251_22138" x1="37.6242" y1="58.116" x2="37.6242" y2="84.727" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint93_linear_251_22138" x1="40.2902" y1="54.6763" x2="40.2902" y2="68.1899" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint94_linear_251_22138" x1="29.5939" y1="105.774" x2="29.5939" y2="127.147" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint95_linear_251_22138" x1="29.7927" y1="115.394" x2="29.7927" y2="138.002" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint96_linear_251_22138" x1="76.1884" y1="5.2037" x2="76.1884" y2="14.9707" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint97_linear_251_22138" x1="73.2024" y1="7.89096" x2="73.2024" y2="22.4934" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint98_linear_251_22138" x1="72.1466" y1="5.2037" x2="72.1466" y2="14.9707" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint99_linear_251_22138" x1="68.0295" y1="17.5325" x2="68.0295" y2="7.89096" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint100_linear_251_22138" x1="75.4759" y1="54.0038" x2="75.4759" y2="69.3641" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint101_linear_251_22138" x1="74.1104" y1="90.0161" x2="74.1104" y2="108.608" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint102_linear_251_22138" x1="72.8339" y1="70.6797" x2="72.8339" y2="88.4203" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint103_linear_251_22138" x1="61.6628" y1="77.0042" x2="61.6628" y2="106.943" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#641C3B"/>
  </linearGradient>
  <linearGradient id="paint104_linear_251_22138" x1="62.9313" y1="87.9159" x2="62.9313" y2="70.6797" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint105_linear_251_22138" x1="72.7428" y1="17.319" x2="72.7428" y2="36.3192" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint106_linear_251_22138" x1="74.8792" y1="38.7049" x2="74.8792" y2="52.7175" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint107_linear_251_22138" x1="66.5946" y1="43.7058" x2="66.5946" y2="67.827" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint108_linear_251_22138" x1="67.8845" y1="38.7049" x2="67.8845" y2="52.8296" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint109_linear_251_22138" x1="74.9872" y1="132.574" x2="74.9872" y2="148.201" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint110_linear_251_22138" x1="39.4911" y1="128.993" x2="39.4911" y2="146.117" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint111_linear_251_22138" x1="40.9853" y1="139.291" x2="40.9853" y2="154.988" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint112_linear_251_22138" x1="34.7107" y1="75.0748" x2="34.7107" y2="103.783" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint113_linear_251_22138" x1="35.4282" y1="69.6176" x2="35.4282" y2="86.5736" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint114_linear_251_22138" x1="48.277" y1="39.0625" x2="48.277" y2="52.4934" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint115_linear_251_22138" x1="36.0195" y1="88.3642" x2="36.0195" y2="106.943" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint116_linear_251_22138" x1="36.0195" y1="96.0871" x2="36.0195" y2="126.25" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint117_linear_251_22138" x1="54.2667" y1="147.26" x2="54.2667" y2="158.206" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint118_linear_251_22138" x1="54.2667" y1="153.84" x2="54.2667" y2="161.931" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint119_linear_251_22138" x1="59.4081" y1="142.648" x2="59.4081" y2="157.421" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint120_linear_251_22138" x1="59.4081" y1="148.076" x2="59.4081" y2="131.4" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint121_linear_251_22138" x1="51.4348" y1="131.4" x2="51.4348" y2="146.117" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint122_linear_251_22138" x1="67.5512" y1="15.894" x2="67.5512" y2="23.2806" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint123_linear_251_22138" x1="65.0785" y1="17.319" x2="65.0785" y2="36.3192" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint124_linear_251_22138" x1="58.6398" y1="24.6789" x2="58.6398" y2="37.5094" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint125_linear_251_22138" x1="54.8498" y1="27.4782" x2="54.8498" y2="51.7729" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint126_linear_251_22138" x1="57.1531" y1="38.6408" x2="57.1531" y2="52.4934" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint127_linear_251_22138" x1="51.4959" y1="43.5937" x2="51.4959" y2="67.3519" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint128_linear_251_22138" x1="45.6003" y1="54.0038" x2="45.6003" y2="68.889" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint129_linear_251_22138" x1="44.5012" y1="58.5937" x2="44.5012" y2="85.2314" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint130_linear_251_22138" x1="68.876" y1="24.4147" x2="68.876" y2="37.5094" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint131_linear_251_22138" x1="67.3115" y1="27.0859" x2="67.3115" y2="51.3459" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#732144"/>
  </linearGradient>
  <linearGradient id="paint132_linear_251_22138" x1="62.7965" y1="54.0732" x2="62.7965" y2="69.3641" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint133_linear_251_22138" x1="62.098" y1="58.8712" x2="62.098" y2="86.3628" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint134_linear_251_22138" x1="48.7201" y1="70.5409" x2="48.7201" y2="87.9159" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint135_linear_251_22138" x1="48.7201" y1="76.2063" x2="48.7201" y2="105.587" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint136_linear_251_22138" x1="45.092" y1="108.776" x2="45.092" y2="130.055" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint137_linear_251_22138" x1="45.092" y1="118.725" x2="45.092" y2="144.746" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint138_linear_251_22138" x1="71.8639" y1="110.372" x2="71.8639" y2="131.147" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint139_linear_251_22138" x1="60.521" y1="130.167" x2="60.521" y2="110.372" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint140_linear_251_22138" x1="61.4508" y1="120.654" x2="61.4508" y2="146.929" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint141_linear_251_22138" x1="57.8304" y1="89.429" x2="57.8304" y2="108.483" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint142_linear_251_22138" x1="57.8304" y1="98.2139" x2="57.8304" y2="128.67" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint143_linear_251_22138" x1="49.8492" y1="89.429" x2="49.8492" y2="107.223" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint144_linear_251_22138" x1="67.4812" y1="163.914" x2="67.4812" y2="158.86" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint145_linear_251_22138" x1="67.4812" y1="163.354" x2="67.4812" y2="166.732" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint146_linear_251_22138" x1="73.6675" y1="149.309" x2="73.6675" y2="158.878" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint147_linear_251_22138" x1="66.3117" y1="158.121" x2="66.3117" y2="149.309" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint148_linear_251_22138" x1="68.889" y1="156.303" x2="68.889" y2="163.215" gradientUnits="userSpaceOnUse">
  <stop stop-color="#9A2F5B"/>
  <stop offset="1" stop-color="#702042"/>
  </linearGradient>
  <linearGradient id="paint149_linear_251_22138" x1="75.8148" y1="166.572" x2="75.8148" y2="164.603" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  <linearGradient id="paint150_linear_251_22138" x1="73.5354" y1="166.572" x2="73.5354" y2="164.603" gradientUnits="userSpaceOnUse">
  <stop stop-color="white"/>
  <stop offset="1" stop-color="#E9BFCD"/>
  </linearGradient>
  </defs>
  </svg>
  
);
