'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var resolve = require('@rollup/plugin-node-resolve');
var commonjs = require('@rollup/plugin-commonjs');
var typescript = require('rollup-plugin-typescript2');
var terser = require('@rollup/plugin-terser');
var sizes = require('rollup-plugin-sizes');
var rollupPluginVisualizer = require('rollup-plugin-visualizer');
var external = require('rollup-plugin-peer-deps-external');
var postcss = require('rollup-plugin-postcss');

// Check if environment variable is set to 'dev'
const isDev = process.env.NODE_ENV === 'dev';

const packageJson = require('./package.json');

/**
 * @type {import('rollup').RollupOptions}
 */
const config = [
  {
    external: ['react', 'react-dom', 'react-native', 'i18next'],
    input: 'src/index.ts',
    output: [
      {
        file: packageJson.module,
        format: 'es',
        sourcemap: true,
      },
      {
        name: 'browser',
        file: packageJson.unpkg,
        format: 'umd',
        sourcemap: true,
      },
      {
        file: packageJson.main,
        format: 'cjs',
        sourcemap: true,
      },
    ],
    plugins: [
      external(),
      resolve(),
      commonjs(),
      typescript(),
      postcss({
        // Extract CSS to the same location as the JS file
        extract: true,
        // Use Sass compiler
        plugins: [],
        // Enable source maps
        sourceMap: true,
        // Enable CSS modules if needed
        modules: true,
        // Use additional plugins like `autoprefixer`
        // plugins: [require('autoprefixer')]
      }),
      isDev && sizes(),
      terser(),
      isDev &&
        rollupPluginVisualizer.visualizer({
          filename: `bundle_stats/browser-es-stats-${packageJson.version}.html`,
        }),
    ],
  },
];

exports.default = config;
